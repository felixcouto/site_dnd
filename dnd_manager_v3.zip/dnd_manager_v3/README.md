# D&D Manager V3

Sistema PHP/MySQL para gerenciamento de fichas de D&D 2024, personagens e mesas.

## Novidades da V3

- Layout renovado e responsivo para abrir/editar personagens e mesas.
- Atributos: Força, Destreza, Constituição, Inteligência, Sabedoria e Carisma.
- Modificador automático pela regra `floor((atributo - 10) / 2)`.
- Bônus de proficiência automático por nível.
- Testes de resistência com proficiência e cálculo automático.
- 18 perícias com atributo-base, proficiência e cálculo automático.
- Combate: CA, iniciativa, velocidade, PV máximo, atual e temporário.
- Mestre/Admin podem alterar PV e demais dados de personagens autorizados.
- Ataques/truques em linhas editáveis.
- Inventário, quantidade, observações e moedas.
- Imagem do personagem e da mesa.
- Admin visualiza todas as mesas e pode editá-las.
- Painel da mesa com jogadores e personagens.
- Rolagem de d4, d6, d8, d10, d12, d20 e d100.
- Expressões como `2d20 + 5`, com até 20 dados por rolagem.
- Histórico de rolagens da mesa, armazenado no MySQL.
- Importação/exportação JSON preservando campos adicionais do JSON original.
- Exportação JSON e impressão em PDF pelo navegador.
- Compatibilidade com personagens importados da V2: os campos antigos são preservados e os campos novos são acrescentados quando a ficha é salva.

## Instalação

1. PHP 8.1+ e MySQL/MariaDB.
2. Copie a pasta para `htdocs`, `www` ou servidor PHP.
3. Importe `database/schema.sql` no MySQL.
4. Confira usuário, senha, banco e host em `config/conexao.php`.
5. Abra `index.php`.
6. Crie um usuário.
7. Para transformar o primeiro usuário em administrador:

```sql
UPDATE usuarios SET tipo='admin' WHERE email='seu@email.com';
```

## Estrutura de dados da V3

Os novos dados ficam dentro do JSON do personagem, mantendo compatibilidade com campos extras:

- `atributos_modificadores`
- `bonus_proficiencia`
- `resistencias_proficientes`
- `resistencias`
- `pericias`
- `combate`
- `ataques`
- `inventario`
- `moedas`
- `pv_temporarios`

O sistema não apaga campos desconhecidos existentes no JSON.

## Observações

Esta versão é uma base funcional para campanha. Ela não tenta substituir um motor completo de regras: não calcula automaticamente todos os efeitos de equipamentos, magias, condições, talentos ou recursos específicos de cada classe. Esses dados podem continuar presentes no JSON e podem ser ampliados nas próximas versões.

As imagens são armazenadas em Base64 no banco para facilitar a instalação local. Em produção, recomenda-se armazenamento de arquivos/objeto com URL e controles adicionais de segurança.
