<?php
require_once __DIR__ . '/../config/layout.php';
exigeLogin();
header('Content-Type: application/json; charset=utf-8');
$u = usuario();
$mesaId = (int)($_GET['mesa_id'] ?? $_POST['mesa_id'] ?? 0);
if ($mesaId < 1 || ($u['tipo'] !== 'admin' && !temMesa($mesaId, $u['id']))) {
    http_response_code(403);
    echo json_encode(['ok'=>false,'error'=>'Acesso negado à mesa.']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        http_response_code(400);
        echo json_encode(['ok'=>false,'error'=>'Token de segurança inválido.']);
        exit;
    }
    $message = trim((string)($_POST['mensagem'] ?? ''));
    if ($message === '' || mb_strlen($message) > 2000) {
        http_response_code(422);
        echo json_encode(['ok'=>false,'error'=>'A mensagem deve ter entre 1 e 2.000 caracteres.']);
        exit;
    }
    $q = $pdo->prepare('INSERT INTO mesa_chat (mesa_id, usuario_id, mensagem) VALUES (?,?,?)');
    $q->execute([$mesaId, $u['id'], $message]);
}
$after = max(0, (int)($_GET['after'] ?? 0));
$q = $pdo->prepare('SELECT c.id,c.usuario_id,u.nome,c.mensagem,c.criado_em
                    FROM mesa_chat c JOIN usuarios u ON u.id=c.usuario_id
                    WHERE c.mesa_id=? AND c.id>?
                    ORDER BY c.id ASC LIMIT 100');
$q->execute([$mesaId, $after]);
echo json_encode(['ok'=>true,'messages'=>$q->fetchAll(PDO::FETCH_ASSOC)], JSON_UNESCAPED_UNICODE);
