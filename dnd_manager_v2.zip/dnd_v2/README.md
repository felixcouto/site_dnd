# D&D Manager V2

Sistema PHP + MySQL para campanhas e fichas. Compatível com o JSON de personagem fornecido, preservando campos desconhecidos durante importação.

## Instalação
1. PHP 8.1+ e MySQL/MariaDB.
2. Crie/importa `database/schema.sql` no MySQL.
3. Ajuste `config/conexao.php`.
4. Coloque a pasta em `htdocs/dnd_v2`.
5. Acesse `/dnd_v2/`.
6. Cadastre uma conta. O primeiro administrador pode ser definido no MySQL: `UPDATE usuarios SET tipo='admin' WHERE email='...';`

## V2
- usuários e papéis jogador/mestre/admin;
- criação/entrada em mesas por código;
- Mestre acessa e edita fichas da mesa;
- importação do JSON fornecido, objeto ou array;
- imagem da ficha e da mesa em Base64;
- exportação de personagem JSON;
- exportação de mesa JSON com personagens;
- páginas de impressão para salvar como PDF de personagem e mesa;
- logs básicos;
- preservação de campos adicionais do JSON na edição/importação.

### PDF
Os botões PDF abrem uma versão própria para impressão. No navegador, use **Imprimir > Salvar como PDF**. Isso evita dependências externas e funciona em instalação local/offline.
