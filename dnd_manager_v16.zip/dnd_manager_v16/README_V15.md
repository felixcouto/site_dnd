# D&D Manager V15

## Atualizações
- Layout de rolagem redesenhado em tema escuro azul, com painéis compactos e adaptação responsiva inspirada na referência visual enviada e na experiência de rolagem do D&D Dice Roller.
- Imagens de dados menores para reduzir a área ocupada e permitir visualizar mais resultados simultaneamente.
- Suporte a d2 além de d4, d6, d8, d10, d12, d20, d100 e Poker.
- Quantidade visual de dados correspondente à expressão, com valor de cada dado, tipo, modificador e total.
- Histórico visual para cada dado numérico e histórico Poker com inicial/substituição/final.
- Imagens locais SVG; não dependem de serviços externos.

## Instalação
1. Extraia a pasta em seu servidor PHP.
2. Configure banco de dados em `config/conexao.php`.
3. Importe `database/schema.sql` se for instalação nova; para atualização, mantenha o banco existente.
4. Faça login e abra uma mesa para usar a rolagem.

## Validação
A validação é estática (sintaxe PHP/JavaScript e integridade do ZIP). O teste integrado deve ser executado em ambiente PHP/MySQL antes de publicar.
