# D&D Manager V16

## Rolagem visual
- Rolagem de dados com script visual animado: os dados giram/ressaltam e depois exibem o valor individual de cada dado.
- Exibe quantidade, tipo de dado, posição, modificador e total calculado.
- Atalhos para d2, d3, d4, d5, d6, d7, d8, d9, d10, d12, d20 e d100.
- Mantém a rolagem Poker e seu fluxo de rerrolagem/histórico.
- O movimento respeita a preferência de redução de animações do sistema operacional.
- A animação é visual; os valores são gerados no servidor PHP com `random_int`, não pela animação.

## Referência
A interface e o fluxo de configuração foram inspirados no modelo de escolha da quantidade de dados e do número de lados da referência informada pelo usuário: https://www.dados-online.pt/dados-para-rpg.html. A implementação é própria e não copia o código-fonte do site de referência.

## Instalação
1. Extraia o pacote no servidor PHP.
2. Configure `config/conexao.php`.
3. Em instalação nova, importe `database/schema.sql`; em atualização, preserve o banco existente.
4. Acesse uma mesa e teste a rolagem.

## Nota de validação
A validação estática deve ser executada antes da publicação. Teste integrado em PHP/MySQL e navegador não é substituído por verificação de sintaxe.
