<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/auth.php';
$usuarioNav = usuarioLogado() ? usuarioAtual($pdo) : null;
$pageTitle = $pageTitle ?? 'D&D Campaign Manager';
?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($pageTitle) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
<link href="/dnd/public/css/app.css" rel="stylesheet">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark app-nav">
  <div class="container">
    <a class="navbar-brand fw-bold" href="/dnd/dashboard/">⚔ D&D Campaign Manager</a>
    <?php if ($usuarioNav): ?>
    <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navMain"><span class="navbar-toggler-icon"></span></button>
    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto">
        <li class="nav-item"><a class="nav-link" href="/dnd/dashboard/"><i class="bi bi-grid"></i> Dashboard</a></li>
        <li class="nav-item"><a class="nav-link" href="/dnd/personagens/"><i class="bi bi-person-badge"></i> Personagens</a></li>
        <li class="nav-item"><a class="nav-link" href="/dnd/mesas/"><i class="bi bi-dice-5"></i> Mesas</a></li>
        <?php if (in_array($usuarioNav['tipo'], ['mestre','admin'], true)): ?>
        <li class="nav-item"><a class="nav-link" href="/dnd/mestre/"><i class="bi bi-shield"></i> Mestre</a></li>
        <?php endif; ?>
      </ul>
      <span class="navbar-text me-3"><?= h($usuarioNav['nome']) ?></span>
      <a class="btn btn-outline-light btn-sm" href="/dnd/auth/logout.php">Sair</a>
    </div>
    <?php endif; ?>
  </div>
</nav>
<main class="container py-4">
