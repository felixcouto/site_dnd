</main>
<footer class="py-4 text-center text-secondary small">
  D&D Campaign Manager · MVP
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/dnd/public/js/app.js"></script>
</body>
</html>
