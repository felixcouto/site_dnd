<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: /dnd/dashboard/');
} else {
    header('Location: /dnd/auth/login.php');
}
exit;
