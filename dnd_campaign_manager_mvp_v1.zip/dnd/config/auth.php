<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

function usuarioLogado(): bool {
    return isset($_SESSION['usuario_id']);
}

function exigirLogin(): void {
    if (!usuarioLogado()) {
        header('Location: /dnd/auth/login.php');
        exit;
    }
}

function usuarioAtual(PDO $pdo): array {
    exigirLogin();
    static $usuario = null;
    if ($usuario === null) {
        $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE id = ? AND ativo = 1');
        $stmt->execute([$_SESSION['usuario_id']]);
        $usuario = $stmt->fetch();
        if (!$usuario) {
            session_destroy();
            header('Location: /dnd/auth/login.php');
            exit;
        }
    }
    return $usuario;
}

function exigirMestre(PDO $pdo): array {
    $u = usuarioAtual($pdo);
    if (!in_array($u['tipo'], ['mestre','admin'], true)) {
        http_response_code(403);
        exit('Acesso restrito ao Mestre.');
    }
    return $u;
}

function h(?string $v): string {
    return htmlspecialchars($v ?? '', ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never {
    header("Location: {$url}");
    exit;
}
