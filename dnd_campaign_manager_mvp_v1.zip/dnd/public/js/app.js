document.addEventListener('DOMContentLoaded',()=> {
 document.querySelectorAll('[data-auto-mod]').forEach(el=>{
   const score=parseInt(el.dataset.autoMod||'10',10);
   const mod=Math.floor((score-10)/2);
   el.textContent=(mod>=0?'+':'')+mod;
 });
});
