<?php
require_once __DIR__.'/../config/conexao.php'; require_once __DIR__.'/../config/auth.php';
$u=usuarioAtual($pdo);$id=(int)($_GET['id']??0);
$stmt=$pdo->prepare('SELECT p.*,u.nome AS jogador FROM personagens p JOIN usuarios u ON u.id=p.usuario_id WHERE p.id=?');$stmt->execute([$id]);$p=$stmt->fetch();
if(!$p) {http_response_code(404);exit('Personagem não encontrado.');}
$ehDono=(int)$p['usuario_id']===(int)$u['id'];
$stmt=$pdo->prepare('SELECT m.id,m.nome FROM mesas m JOIN mesa_jogadores mj ON mj.mesa_id=m.id WHERE mj.personagem_id=?');$stmt->execute([$id]);$mesa=$stmt->fetch();
$ehMestre=false;if($mesa){$stmt=$pdo->prepare('SELECT mestre_id FROM mesas WHERE id=?');$stmt->execute([$mesa['id']]);$ehMestre=(int)$stmt->fetchColumn()===(int)$u['id'];}
if(!$ehDono&&!$ehMestre&&$u['tipo']!=='admin'){http_response_code(403);exit('Sem permissão.');}
if($_SERVER['REQUEST_METHOD']==='POST'){
 $fields=['nome','classe','especie','antecedente','alinhamento','descricao','velocidade','dado_vida'];$data=[];
 foreach($fields as $f)$data[$f]=trim($_POST[$f]??'');
 foreach(['nivel','xp','forca','destreza','constituicao','inteligencia','sabedoria','carisma','ca','iniciativa','hp_max','hp_atual','hp_temporario','proficiencia'] as $f)$data[$f]=(int)($_POST[$f]??0);
 $sql='UPDATE personagens SET nome=?,classe=?,nivel=?,especie=?,antecedente=?,xp=?,alinhamento=?,forca=?,destreza=?,constituicao=?,inteligencia=?,sabedoria=?,carisma=?,ca=?,iniciativa=?,velocidade=?,hp_max=?,hp_atual=?,hp_temporario=?,dado_vida=?,proficiencia=?,descricao=? WHERE id=?';
 $pdo->prepare($sql)->execute([$data['nome'],$data['classe'],$data['nivel'],$data['especie'],$data['antecedente'],$data['xp'],$data['alinhamento'],$data['forca'],$data['destreza'],$data['constituicao'],$data['inteligencia'],$data['sabedoria'],$data['carisma'],$data['ca'],$data['iniciativa'],$data['velocidade'],$data['hp_max'],$data['hp_atual'],$data['hp_temporario'],$data['dado_vida'],$data['proficiencia'],$data['descricao'],$id]);
 $msg='Ficha atualizada.';
 $stmt=$pdo->prepare('SELECT p.*,u.nome AS jogador FROM personagens p JOIN usuarios u ON u.id=p.usuario_id WHERE p.id=?');$stmt->execute([$id]);$p=$stmt->fetch();
}
function mod(int $score): string {$m=(int)floor(($score-10)/2);return $m>=0?'+'.$m:(string)$m;}
$pageTitle='Ficha · '.$p['nome']; include __DIR__.'/../components/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h1 class="mb-0"><?=h($p['nome'])?></h1><div class="text-secondary"><?=h($p['classe'])?> · Nível <?=$p['nivel']?> · Jogador: <?=h($p['jogador'])?></div></div><?php if($mesa): ?><span class="badge text-bg-warning"><?=h($mesa['nome'])?></span><?php endif; ?></div>
<?php if(isset($msg)): ?><div class="alert alert-success"><?=$msg?></div><?php endif; ?>
<form method="post" class="sheet">
<div class="row g-3 mb-4">
<?php foreach(['forca'=>'FORÇA','destreza'=>'DESTREZA','constituicao'=>'CONSTITUIÇÃO','inteligencia'=>'INTELIGÊNCIA','sabedoria'=>'SABEDORIA','carisma'=>'CARISMA'] as $k=>$label): ?><div class="col-6 col-md-2"><div class="ability"><div class="small fw-bold"><?=$label?></div><input class="form-control text-center fw-bold fs-4" type="number" name="<?=$k?>" value="<?=$p[$k]?>" min="1" max="30"><div class="mod"><?=mod((int)$p[$k])?></div></div></div><?php endforeach; ?>
</div>
<div class="row g-3 mb-4">
<div class="col-md-3"><div class="ability"><div>CLASSE DE ARMADURA</div><input class="form-control text-center fw-bold fs-3" name="ca" value="<?=$p['ca']?>"></div></div>
<div class="col-md-3"><div class="ability"><div>INICIATIVA</div><input class="form-control text-center fw-bold fs-3" name="iniciativa" value="<?=$p['iniciativa']?>"></div></div>
<div class="col-md-3"><div class="ability"><div>VELOCIDADE</div><input class="form-control text-center fw-bold fs-3" name="velocidade" value="<?=h($p['velocidade'])?>"></div></div>
<div class="col-md-3"><div class="hp-box"><div class="small">PONTOS DE VIDA</div><div class="row g-1"><div class="col"><label class="small">Máx.</label><input class="form-control" name="hp_max" value="<?=$p['hp_max']?>"></div><div class="col"><label class="small">Atual</label><input class="form-control" name="hp_atual" value="<?=$p['hp_atual']?>"></div><div class="col"><label class="small">Temp.</label><input class="form-control" name="hp_temporario" value="<?=$p['hp_temporario']?>"></div></div></div></div>
</div>
<h5 class="section-title">Identidade</h5><div class="row g-3 mb-4">
<div class="col-md-4"><label class="form-label">Nome</label><input class="form-control" name="nome" value="<?=h($p['nome'])?>"></div>
<div class="col-md-2"><label class="form-label">Classe</label><input class="form-control" name="classe" value="<?=h($p['classe'])?>"></div>
<div class="col-md-2"><label class="form-label">Nível</label><input class="form-control" name="nivel" value="<?=$p['nivel']?>"></div>
<div class="col-md-2"><label class="form-label">Espécie</label><input class="form-control" name="especie" value="<?=h($p['especie'])?>"></div>
<div class="col-md-2"><label class="form-label">Antecedente</label><input class="form-control" name="antecedente" value="<?=h($p['antecedente'])?>"></div>
<div class="col-md-3"><label class="form-label">XP</label><input class="form-control" name="xp" value="<?=$p['xp']?>"></div>
<div class="col-md-3"><label class="form-label">Bônus de proficiência</label><input class="form-control" name="proficiencia" value="<?=$p['proficiencia']?>"></div>
<div class="col-md-3"><label class="form-label">Dado de vida</label><input class="form-control" name="dado_vida" value="<?=h($p['dado_vida'])?>"></div>
<div class="col-md-3"><label class="form-label">Alinhamento</label><input class="form-control" name="alinhamento" value="<?=h($p['alinhamento'])?>"></div>
</div>
<h5 class="section-title">Descrição</h5><textarea class="form-control mb-4" rows="4" name="descricao"><?=h($p['descricao'])?></textarea>
<button class="btn btn-dark"><i class="bi bi-save"></i> Salvar ficha</button>
<a class="btn btn-outline-secondary" href="/dnd/personagens/">Voltar</a>
</form>
<?php include __DIR__.'/../components/footer.php'; ?>
