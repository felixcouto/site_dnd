<?php
require_once __DIR__.'/../config/conexao.php'; require_once __DIR__.'/../config/auth.php';
$u=usuarioAtual($pdo); $erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nome=trim($_POST['nome']??''); $classe=trim($_POST['classe']??''); $nivel=max(1,min(20,(int)($_POST['nivel']??1)));
 $especie=trim($_POST['especie']??'');$antecedente=trim($_POST['antecedente']??'');$xp=max(0,(int)($_POST['xp']??0));
 $vals=[]; foreach(['forca','destreza','constituicao','inteligencia','sabedoria','carisma'] as $a){$vals[$a]=max(1,min(30,(int)($_POST[$a]??10)));}
 $hp=max(1,(int)($_POST['hp_max']??10));$ca=(int)($_POST['ca']??10);$vel=trim($_POST['velocidade']??'9 m');
 if($nome==='')$erro='Informe o nome do personagem.';
 else{
  $sql='INSERT INTO personagens(usuario_id,nome,classe,nivel,especie,antecedente,xp,forca,destreza,constituicao,inteligencia,sabedoria,carisma,hp_max,hp_atual,ca,velocidade) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)';
  $stmt=$pdo->prepare($sql);$stmt->execute([$u['id'],$nome,$classe,$nivel,$especie,$antecedente,$xp,$vals['forca'],$vals['destreza'],$vals['constituicao'],$vals['inteligencia'],$vals['sabedoria'],$vals['carisma'],$hp,$hp,$ca,$vel]);
  redirect('/dnd/personagens/ficha.php?id='.$pdo->lastInsertId());
 }
}
$pageTitle='Criar personagem'; include __DIR__.'/../components/header.php';
?>
<h1 class="mb-4">Criar personagem</h1>
<?php if($erro): ?><div class="alert alert-danger"><?=h($erro)?></div><?php endif; ?>
<form method="post" class="card p-4">
<h5 class="section-title">Identidade</h5><div class="row g-3 mb-4">
<div class="col-md-6"><label class="form-label">Nome</label><input class="form-control" name="nome" required></div>
<div class="col-md-3"><label class="form-label">Classe</label><input class="form-control" name="classe" placeholder="Guerreiro"></div>
<div class="col-md-3"><label class="form-label">Nível</label><input class="form-control" type="number" min="1" max="20" name="nivel" value="1"></div>
<div class="col-md-4"><label class="form-label">Espécie</label><input class="form-control" name="especie" placeholder="Humano"></div>
<div class="col-md-4"><label class="form-label">Antecedente</label><input class="form-control" name="antecedente" placeholder="Nobre"></div>
<div class="col-md-4"><label class="form-label">XP</label><input class="form-control" type="number" name="xp" value="0"></div>
</div>
<h5 class="section-title">Atributos</h5><div class="row g-3 mb-4"><?php foreach(['forca'=>'Força','destreza'=>'Destreza','constituicao'=>'Constituição','inteligencia'=>'Inteligência','sabedoria'=>'Sabedoria','carisma'=>'Carisma'] as $k=>$label): ?><div class="col-6 col-md-2"><label class="form-label"><?=$label?></label><input class="form-control" type="number" name="<?=$k?>" value="10" min="1" max="30"></div><?php endforeach; ?></div>
<h5 class="section-title">Combate</h5><div class="row g-3"><div class="col-md-3"><label class="form-label">HP máximo</label><input class="form-control" type="number" name="hp_max" value="10"></div><div class="col-md-3"><label class="form-label">CA</label><input class="form-control" type="number" name="ca" value="10"></div><div class="col-md-3"><label class="form-label">Velocidade</label><input class="form-control" name="velocidade" value="9 m"></div></div>
<div class="mt-4"><button class="btn btn-dark">Criar ficha</button> <a class="btn btn-outline-secondary" href="/dnd/personagens/">Cancelar</a></div>
</form>
<?php include __DIR__.'/../components/footer.php'; ?>
