<?php
require_once __DIR__.'/../config/conexao.php'; require_once __DIR__.'/../config/auth.php';
$u=usuarioAtual($pdo);
$stmt=$pdo->prepare('SELECT * FROM personagens WHERE usuario_id=? ORDER BY atualizado_em DESC');$stmt->execute([$u['id']]);$lista=$stmt->fetchAll();
$pageTitle='Meus personagens'; include __DIR__.'/../components/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1>Meus personagens</h1><p class="text-secondary mb-0">Suas fichas de D&D 2024.</p></div><a class="btn btn-dark" href="/dnd/personagens/criar.php"><i class="bi bi-plus-lg"></i> Criar personagem</a></div>
<div class="row g-3">
<?php foreach($lista as $p): ?><div class="col-md-6 col-lg-4"><div class="card p-4 h-100"><div class="d-flex justify-content-between"><h3><?=h($p['nome'])?></h3><span class="badge text-bg-dark">Nível <?=$p['nivel']?></span></div><p><?=h($p['classe'])?> · <?=h($p['especie'])?></p><div class="small text-secondary">HP <?=$p['hp_atual']?>/<?=$p['hp_max']?> · CA <?=$p['ca']?></div><a class="btn btn-outline-dark mt-3" href="/dnd/personagens/ficha.php?id=<?=$p['id']?>">Abrir ficha</a></div></div><?php endforeach; ?>
<?php if(!$lista): ?><div class="col-12"><div class="alert alert-light border">Nenhum personagem ainda.</div></div><?php endif; ?>
</div>
<?php include __DIR__.'/../components/footer.php'; ?>
