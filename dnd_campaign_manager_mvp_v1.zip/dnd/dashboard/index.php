<?php
require_once __DIR__.'/../config/conexao.php'; require_once __DIR__.'/../config/auth.php';
$u=usuarioAtual($pdo);
$stmt=$pdo->prepare('SELECT COUNT(*) FROM personagens WHERE usuario_id=?');$stmt->execute([$u['id']]);$personagens=(int)$stmt->fetchColumn();
$stmt=$pdo->prepare('SELECT COUNT(*) FROM mesa_jogadores WHERE usuario_id=?');$stmt->execute([$u['id']]);$mesas=(int)$stmt->fetchColumn();
$stmt=$pdo->prepare("SELECT COUNT(*) FROM mesas WHERE mestre_id=?");$stmt->execute([$u['id']]);$mesasMestre=(int)$stmt->fetchColumn();
$pageTitle='Dashboard'; include __DIR__.'/../components/header.php';
?>
<div class="hero mb-4"><h1 class="display-5 fw-bold">Sua aventura começa aqui.</h1><p class="lead mb-0">Crie personagens, entre em mesas e deixe o Mestre administrar a campanha.</p></div>
<div class="row g-3">
<div class="col-md-4"><div class="card stat-card p-4"><div class="text-secondary">Meus personagens</div><div class="display-5 fw-bold"><?= $personagens ?></div><a href="/dnd/personagens/" class="stretched-link">Gerenciar</a></div></div>
<div class="col-md-4"><div class="card stat-card p-4"><div class="text-secondary">Mesas em que participo</div><div class="display-5 fw-bold"><?= $mesas ?></div><a href="/dnd/mesas/" class="stretched-link">Ver mesas</a></div></div>
<?php if(in_array($u['tipo'],['mestre','admin'],true)): ?><div class="col-md-4"><div class="card stat-card p-4"><div class="text-secondary">Mesas que mestro</div><div class="display-5 fw-bold"><?= $mesasMestre ?></div><a href="/dnd/mestre/" class="stretched-link">Painel do Mestre</a></div></div><?php endif; ?>
</div>
<?php include __DIR__.'/../components/footer.php'; ?>
