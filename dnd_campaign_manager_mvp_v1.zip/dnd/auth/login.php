<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/auth.php';
if (usuarioLogado()) redirect('/dnd/dashboard/');
$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $stmt = $pdo->prepare('SELECT * FROM usuarios WHERE email = ? AND ativo = 1');
    $stmt->execute([$email]);
    $u = $stmt->fetch();
    if ($u && password_verify($senha, $u['senha'])) {
        session_regenerate_id(true);
        $_SESSION['usuario_id'] = $u['id'];
        redirect('/dnd/dashboard/');
    }
    $erro = 'E-mail ou senha inválidos.';
}
$pageTitle='Login';
include __DIR__.'/../components/header.php';
?>
<div class="login-wrap"><div class="card login-card p-4 p-md-5">
<h2 class="fw-bold mb-1">⚔ Entrar</h2><p class="text-secondary">Acesse suas mesas e personagens.</p>
<?php if($erro): ?><div class="alert alert-danger"><?=h($erro)?></div><?php endif; ?>
<form method="post">
<label class="form-label">E-mail</label><input class="form-control mb-3" type="email" name="email" required>
<label class="form-label">Senha</label><input class="form-control mb-3" type="password" name="senha" required>
<button class="btn btn-dark w-100">Entrar</button>
</form>
<div class="text-center mt-3"><a href="/dnd/auth/cadastro.php">Criar uma conta</a></div>
</div></div>
<?php include __DIR__.'/../components/footer.php'; ?>
