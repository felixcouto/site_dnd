<?php
require_once __DIR__ . '/../config/conexao.php';
require_once __DIR__ . '/../config/auth.php';
if (usuarioLogado()) redirect('/dnd/dashboard/');
$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    $nome=trim($_POST['nome']??''); $email=trim($_POST['email']??''); $senha=$_POST['senha']??'';
    if(strlen($nome)<2 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($senha)<6){
        $erro='Informe nome, e-mail válido e senha com pelo menos 6 caracteres.';
    } else {
        try{
            $stmt=$pdo->prepare('INSERT INTO usuarios(nome,email,senha) VALUES(?,?,?)');
            $stmt->execute([$nome,$email,password_hash($senha,PASSWORD_DEFAULT)]);
            redirect('/dnd/auth/login.php');
        }catch(PDOException $e){$erro='Este e-mail já está cadastrado.';}
    }
}
$pageTitle='Criar conta'; include __DIR__.'/../components/header.php';
?>
<div class="login-wrap"><div class="card login-card p-4 p-md-5">
<h2 class="fw-bold">Criar conta</h2><p class="text-secondary">Comece sua campanha.</p>
<?php if($erro): ?><div class="alert alert-danger"><?=h($erro)?></div><?php endif; ?>
<form method="post">
<label class="form-label">Nome</label><input class="form-control mb-3" name="nome" required>
<label class="form-label">E-mail</label><input class="form-control mb-3" type="email" name="email" required>
<label class="form-label">Senha</label><input class="form-control mb-3" type="password" name="senha" minlength="6" required>
<button class="btn btn-dark w-100">Criar conta</button>
</form>
<div class="text-center mt-3"><a href="/dnd/auth/login.php">Já tenho uma conta</a></div>
</div></div>
<?php include __DIR__.'/../components/footer.php'; ?>
