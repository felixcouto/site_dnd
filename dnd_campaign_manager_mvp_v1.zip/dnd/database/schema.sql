CREATE DATABASE IF NOT EXISTS dnd_campaign
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dnd_campaign;

CREATE TABLE usuarios (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    email VARCHAR(180) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('jogador','mestre','admin') NOT NULL DEFAULT 'jogador',
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE mesas (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mestre_id INT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    descricao TEXT NULL,
    codigo_convite VARCHAR(20) NOT NULL UNIQUE,
    criada_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mestre_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE personagens (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    classe VARCHAR(80) NOT NULL DEFAULT '',
    nivel TINYINT UNSIGNED NOT NULL DEFAULT 1,
    especie VARCHAR(80) NOT NULL DEFAULT '',
    antecedente VARCHAR(100) NOT NULL DEFAULT '',
    xp INT UNSIGNED NOT NULL DEFAULT 0,
    alinhamento VARCHAR(60) NOT NULL DEFAULT '',
    forca TINYINT NOT NULL DEFAULT 10,
    destreza TINYINT NOT NULL DEFAULT 10,
    constituicao TINYINT NOT NULL DEFAULT 10,
    inteligencia TINYINT NOT NULL DEFAULT 10,
    sabedoria TINYINT NOT NULL DEFAULT 10,
    carisma TINYINT NOT NULL DEFAULT 10,
    ca SMALLINT NOT NULL DEFAULT 10,
    iniciativa SMALLINT NOT NULL DEFAULT 0,
    velocidade VARCHAR(30) NOT NULL DEFAULT '9 m',
    hp_max SMALLINT UNSIGNED NOT NULL DEFAULT 10,
    hp_atual SMALLINT NOT NULL DEFAULT 10,
    hp_temporario SMALLINT NOT NULL DEFAULT 0,
    dado_vida VARCHAR(20) NOT NULL DEFAULT 'd10',
    proficiencia SMALLINT NOT NULL DEFAULT 2,
    inspiracao TINYINT(1) NOT NULL DEFAULT 0,
    descricao TEXT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE mesa_jogadores (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mesa_id INT UNSIGNED NOT NULL,
    usuario_id INT UNSIGNED NOT NULL,
    personagem_id INT UNSIGNED NULL,
    entrou_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY mesa_usuario (mesa_id, usuario_id),
    FOREIGN KEY (mesa_id) REFERENCES mesas(id) ON DELETE CASCADE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE personagem_pericias (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    personagem_id INT UNSIGNED NOT NULL,
    pericia VARCHAR(80) NOT NULL,
    atributo VARCHAR(20) NOT NULL,
    proficiente TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE CASCADE,
    UNIQUE KEY personagem_pericia (personagem_id, pericia)
) ENGINE=InnoDB;

CREATE TABLE personagem_ataques (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    personagem_id INT UNSIGNED NOT NULL,
    nome VARCHAR(120) NOT NULL,
    bonus VARCHAR(30) NOT NULL DEFAULT '',
    dano VARCHAR(80) NOT NULL DEFAULT '',
    observacao VARCHAR(255) NULL,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE personagem_inventario (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    personagem_id INT UNSIGNED NOT NULL,
    item VARCHAR(150) NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    observacao VARCHAR(255) NULL,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE personagem_magias (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    personagem_id INT UNSIGNED NOT NULL,
    nome VARCHAR(150) NOT NULL,
    nivel TINYINT UNSIGNED NOT NULL DEFAULT 0,
    preparada TINYINT(1) NOT NULL DEFAULT 0,
    observacao VARCHAR(255) NULL,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE rolagens (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    mesa_id INT UNSIGNED NULL,
    usuario_id INT UNSIGNED NOT NULL,
    personagem_id INT UNSIGNED NULL,
    expressao VARCHAR(80) NOT NULL,
    resultado INT NOT NULL,
    detalhes VARCHAR(255) NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mesa_id) REFERENCES mesas(id) ON DELETE SET NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE INDEX idx_personagens_usuario ON personagens(usuario_id);
CREATE INDEX idx_mesa_jogadores_mesa ON mesa_jogadores(mesa_id);
CREATE INDEX idx_rolagens_mesa ON rolagens(mesa_id);
