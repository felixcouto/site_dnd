# D&D Campaign Manager

MVP em PHP 8 + MySQL + Bootstrap 5.3 para criação e gerenciamento de mesas e personagens de D&D 2024.

## Requisitos
- PHP 8.1+
- MySQL 8+ / MariaDB
- Apache (XAMPP, WAMP ou similar)
- Extensão PDO MySQL habilitada

## Instalação
1. Copie a pasta `dnd` para `htdocs`.
2. Crie um banco chamado `dnd_campaign`.
3. Importe `database/schema.sql`.
4. Edite `config/conexao.php` com usuário/senha do MySQL.
5. Acesse `http://localhost/dnd/`.
6. Cadastre uma conta. O primeiro usuário pode ser promovido para mestre diretamente no banco:
   `UPDATE usuarios SET tipo='mestre' WHERE email='seu@email.com';`

## Fluxo
- Jogador cria conta e personagens.
- Mestre cria uma mesa e recebe um código de convite.
- Jogador entra na mesa usando o código.
- O jogador associa um personagem à mesa.
- Mestre visualiza e edita as fichas dos personagens da mesa.

## Segurança
O MVP usa PDO com prepared statements, `password_hash`, sessões e verificações de autorização no servidor.
