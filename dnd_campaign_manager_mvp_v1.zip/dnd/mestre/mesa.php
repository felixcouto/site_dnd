<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=exigirMestre($pdo);$id=(int)($_GET['id']??0);
$q=$pdo->prepare('SELECT * FROM mesas WHERE id=? AND mestre_id=?');$q->execute([$id,$u['id']]);$m=$q->fetch();if(!$m)exit('Mesa não encontrada.');
$q=$pdo->prepare('SELECT mj.*,u.nome usuario,p.nome personagem,p.classe,p.nivel,p.hp_atual,p.hp_max,p.ca FROM mesa_jogadores mj JOIN usuarios u ON u.id=mj.usuario_id LEFT JOIN personagens p ON p.id=mj.personagem_id WHERE mj.mesa_id=? ORDER BY u.nome');$q->execute([$id]);$jogadores=$q->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['remover'])){
 $uid=(int)$_POST['remover'];if($uid!==$u['id']){$pdo->prepare('DELETE FROM mesa_jogadores WHERE mesa_id=? AND usuario_id=?')->execute([$id,$uid]);}redirect('/dnd/mestre/mesa.php?id='.$id);
}
$pageTitle='Mesa · '.$m['nome'];include __DIR__.'/../components/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-3"><div><h1><?=h($m['nome'])?></h1><p class="text-secondary"><?=h($m['descricao'])?></p></div><div class="text-end"><div class="small text-secondary">Código de convite</div><span class="badge text-bg-warning fs-6"><?=h($m['codigo_convite'])?></span></div></div>
<div class="card p-4"><h4>Jogadores e personagens</h4><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Jogador</th><th>Personagem</th><th>Nível</th><th>HP</th><th>CA</th><th></th></tr></thead><tbody>
<?php foreach($jogadores as $j): ?><tr><td><?=h($j['usuario'])?></td><td><?php if($j['personagem']): ?><strong><?=h($j['personagem'])?></strong><div class="small text-secondary"><?=h($j['classe'])?></div><?php else: ?><span class="text-secondary">Sem personagem</span><?php endif; ?></td><td><?=$j['nivel']??'-'?></td><td><?=$j['hp_atual']??'-'?>/<?=$j['hp_max']??'-'?></td><td><?=$j['ca']??'-'?></td><td><?php if($j['personagem']): ?><a class="btn btn-sm btn-dark" href="/dnd/personagens/ficha.php?id=<?=$j['personagem_id']?>">Editar ficha</a><?php endif; ?><?php if((int)$j['usuario_id']!==$u['id']): ?><form method="post" class="d-inline"><button name="remover" value="<?=$j['usuario_id']?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remover jogador da mesa?')">Remover</button></form><?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div></div>
<?php include __DIR__.'/../components/footer.php'; ?>
