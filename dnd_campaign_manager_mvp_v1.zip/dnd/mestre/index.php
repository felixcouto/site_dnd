<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=exigirMestre($pdo);
$q=$pdo->prepare('SELECT m.*,COUNT(mj.id) jogadores FROM mesas m LEFT JOIN mesa_jogadores mj ON mj.mesa_id=m.id WHERE m.mestre_id=? GROUP BY m.id ORDER BY m.criada_em DESC');$q->execute([$u['id']]);$mesas=$q->fetchAll();
$pageTitle='Painel do Mestre';include __DIR__.'/../components/header.php';
?>
<h1>Painel do Mestre</h1><p class="text-secondary">Administre suas campanhas e fichas.</p><div class="row g-3"><?php foreach($mesas as $m): ?><div class="col-md-6"><div class="card p-4"><h3><?=h($m['nome'])?></h3><p><?=h($m['descricao'])?></p><div class="mb-3"><span class="badge text-bg-dark"><?=$m['jogadores']?> participantes</span> <span class="badge text-bg-warning">Código: <?=h($m['codigo_convite'])?></span></div><a class="btn btn-dark" href="/dnd/mestre/mesa.php?id=<?=$m['id']?>">Gerenciar mesa</a></div></div><?php endforeach; ?></div>
<?php include __DIR__.'/../components/footer.php'; ?>
