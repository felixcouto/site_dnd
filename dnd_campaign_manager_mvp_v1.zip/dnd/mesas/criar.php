<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=exigirMestre($pdo);$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $nome=trim($_POST['nome']??'');$desc=trim($_POST['descricao']??'');
 if(!$nome)$erro='Informe o nome da mesa.';
 else{
  do{$codigo=strtoupper(substr(bin2hex(random_bytes(5)),0,8));$q=$pdo->prepare('SELECT COUNT(*) FROM mesas WHERE codigo_convite=?');$q->execute([$codigo]);}while($q->fetchColumn());
  $pdo->prepare('INSERT INTO mesas(mestre_id,nome,descricao,codigo_convite) VALUES(?,?,?,?)')->execute([$u['id'],$nome,$desc,$codigo]);
  $id=$pdo->lastInsertId();
  $pdo->prepare('INSERT INTO mesa_jogadores(mesa_id,usuario_id) VALUES(?,?)')->execute([$id,$u['id']]);
  redirect('/dnd/mestre/mesa.php?id='.$id);
 }
}
$pageTitle='Criar mesa';include __DIR__.'/../components/header.php';
?>
<h1>Criar mesa</h1><form method="post" class="card p-4 mt-3"><?php if($erro): ?><div class="alert alert-danger"><?=h($erro)?></div><?php endif; ?><label class="form-label">Nome</label><input class="form-control mb-3" name="nome" required><label class="form-label">Descrição</label><textarea class="form-control mb-3" name="descricao" rows="4"></textarea><button class="btn btn-dark">Criar mesa</button></form>
<?php include __DIR__.'/../components/footer.php'; ?>
