<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=usuarioAtual($pdo);$erro='';$ok='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $codigo=strtoupper(trim($_POST['codigo']??''));$q=$pdo->prepare('SELECT * FROM mesas WHERE codigo_convite=?');$q->execute([$codigo]);$m=$q->fetch();
 if(!$m)$erro='Código de convite não encontrado.';
 else{try{$pdo->prepare('INSERT INTO mesa_jogadores(mesa_id,usuario_id) VALUES(?,?)')->execute([$m['id'],$u['id']]);$ok='Você entrou na mesa '.h($m['nome']).'.';}catch(PDOException $e){$erro='Você já está nessa mesa.';}}
}
$pageTitle='Entrar em mesa';include __DIR__.'/../components/header.php';
?>
<h1>Entrar em uma mesa</h1><div class="card p-4 mt-3"><?php if($erro): ?><div class="alert alert-danger"><?=$erro?></div><?php endif; ?><?php if($ok): ?><div class="alert alert-success"><?=$ok?></div><?php endif; ?><form method="post"><label class="form-label">Código da mesa</label><input class="form-control mb-3 text-uppercase" name="codigo" maxlength="20" required><button class="btn btn-dark">Entrar</button></form></div>
<?php include __DIR__.'/../components/footer.php'; ?>
