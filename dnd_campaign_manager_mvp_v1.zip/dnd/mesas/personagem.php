<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=usuarioAtual($pdo);$mesaId=(int)($_GET['mesa']??0);
$q=$pdo->prepare('SELECT * FROM mesas WHERE id=?');$q->execute([$mesaId]);$m=$q->fetch();if(!$m)exit('Mesa não encontrada.');
$q=$pdo->prepare('SELECT * FROM personagens WHERE usuario_id=? ORDER BY nome');$q->execute([$u['id']]);$ps=$q->fetchAll();
if($_SERVER['REQUEST_METHOD']==='POST'){ $pid=(int)($_POST['personagem_id']??0);$q=$pdo->prepare('UPDATE mesa_jogadores SET personagem_id=? WHERE mesa_id=? AND usuario_id=?');$q->execute([$pid,$mesaId,$u['id']]);redirect('/dnd/mesas/');}
$pageTitle='Associar personagem';include __DIR__.'/../components/header.php';
?>
<h1><?=h($m['nome'])?></h1><div class="card p-4 mt-3"><form method="post"><label class="form-label">Escolha seu personagem</label><select class="form-select mb-3" name="personagem_id" required><?php foreach($ps as $p): ?><option value="<?=$p['id']?>"><?=h($p['nome'])?> · <?=h($p['classe'])?> nível <?=$p['nivel']?></option><?php endforeach; ?></select><button class="btn btn-dark">Associar</button></form></div>
<?php include __DIR__.'/../components/footer.php'; ?>
