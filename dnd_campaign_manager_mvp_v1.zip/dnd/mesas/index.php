<?php
require_once __DIR__.'/../config/conexao.php';require_once __DIR__.'/../config/auth.php';$u=usuarioAtual($pdo);
$stmt=$pdo->prepare('SELECT m.*,mj.personagem_id FROM mesas m JOIN mesa_jogadores mj ON mj.mesa_id=m.id WHERE mj.usuario_id=? ORDER BY m.criada_em DESC');$stmt->execute([$u['id']]);$mesas=$stmt->fetchAll();
$pageTitle='Mesas';include __DIR__.'/../components/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1>Mesas</h1><p class="text-secondary">Participe das campanhas.</p></div><div><a class="btn btn-dark" href="/dnd/mesas/entrar.php">Entrar com código</a> <?php if(in_array($u['tipo'],['mestre','admin'],true)): ?><a class="btn btn-outline-dark" href="/dnd/mesas/criar.php">Criar mesa</a><?php endif; ?></div></div>
<div class="row g-3"><?php foreach($mesas as $m): ?><div class="col-md-6"><div class="card p-4"><h3><?=h($m['nome'])?></h3><p><?=h($m['descricao'])?></p><?php if($m['personagem_id']): ?><a class="btn btn-dark" href="/dnd/personagens/ficha.php?id=<?=$m['personagem_id']?>">Abrir meu personagem</a><?php else: ?><a class="btn btn-outline-dark" href="/dnd/mesas/personagem.php?mesa=<?=$m['id']?>">Associar personagem</a><?php endif; ?></div></div><?php endforeach; ?><?php if(!$mesas): ?><div class="col-12"><div class="alert alert-light border">Você ainda não participa de nenhuma mesa.</div></div><?php endif; ?></div>
<?php include __DIR__.'/../components/footer.php'; ?>
