<?php
require '../config/layout.php';
exigeLogin();
$u=usuario();
$id=(int)($_GET['id']??0);
$s=$pdo->prepare('SELECT m.*,u.nome mestre FROM mesas m JOIN usuarios u ON u.id=m.mestre_id WHERE m.id=?');$s->execute([$id]);$m=$s->fetch();
if(!$m||($u['tipo']!=='admin'&&!temMesa($id,$u['id']))) die('Sem acesso.');
$s=$pdo->prepare('SELECT p.*,u.nome jogador FROM personagens p JOIN usuarios u ON u.id=p.usuario_id WHERE p.mesa_id=? ORDER BY p.nome');$s->execute([$id]);$ps=$s->fetchAll();
$ehMestre=$m['mestre_id']==$u['id']||$u['tipo']==='admin';
$s=$pdo->prepare('SELECT r.*,u.nome usuario,p.nome personagem FROM rolagens r JOIN usuarios u ON u.id=r.usuario_id LEFT JOIN personagens p ON p.id=r.personagem_id WHERE r.mesa_id=? ORDER BY r.id DESC LIMIT 60');$s->execute([$id]);$rolls=$s->fetchAll();
$member=$pdo->prepare('SELECT u.id,u.nome,mm.funcao FROM mesa_membros mm JOIN usuarios u ON u.id=mm.usuario_id WHERE mm.mesa_id=? ORDER BY u.nome');$member->execute([$id]);$members=$member->fetchAll();
top('Mesa · '.$m['nome']);
?>
<div class="card sheet-head">
<?php if($m['imagem']):?><img class="preview-square" src="<?=h($m['imagem'])?>"><?php endif;?>
<div class="sheet-title"><h1><?=h($m['nome'])?></h1><p><?=h($m['descricao'])?></p><div class="tabs"><span class="tag">Código <?=h($m['codigo'])?></span><span class="tag">Mestre: <?=h($m['mestre'])?></span><span class="tag"><?=count($members)?> jogadores</span><span class="tag"><?=count($ps)?> personagens</span></div></div>
<div class="sheet-actions"><?php if($ehMestre):?><a class="btn gold" href="editar.php?id=<?=$id?>">Editar mesa</a><?php endif;?><a class="btn" href="../export/mesa.php?id=<?=$id?>">JSON</a><a class="btn" target="_blank" href="../export/mesa_pdf.php?id=<?=$id?>">PDF</a></div>
</div>


<div class="card section" id="mesaChat">
 <div class="section-title"><h2>💬 Conversas da mesa</h2><span class="tag">Geral e particulares</span></div>
 <p class="small">A conversa geral é visível a todos. Conversas particulares são visíveis somente aos participantes envolvidos; o mestre interpreta NPCs e monstros. Histórico preservado.</p>
 <div class="grid-2">
  <div><label>Conversar com</label><select class="input" id="chatTarget"><option value="geral:0">🌐 Conversa geral</option></select></div>
  <div><label>Falar como</label><select class="input" id="chatActor"><option value="usuario:<?= (int)$u['id'] ?>"><?=h($u['nome'])?> (perfil)</option></select></div>
 </div>
 <div id="chatMessages" style="height:330px;overflow:auto;background:#0b1422;border:1px solid #34445b;border-radius:10px;padding:12px" aria-live="polite"></div>
 <form id="mesaChatForm" class="section" style="display:flex;gap:8px;align-items:end">
  <input type="hidden" name="mesa_id" value="<?=$id?>"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>">
  <input type="hidden" name="remetente_tipo" id="chatSenderType" value="usuario"><input type="hidden" name="remetente_id" id="chatSenderId" value="<?=(int)$u['id']?>">
  <input type="hidden" name="destinatario_tipo" id="chatRecipientType" value="geral"><input type="hidden" name="destinatario_id" id="chatRecipientId" value="0">
  <div style="flex:1"><label for="chatMessage">Mensagem</label><input class="input" id="chatMessage" name="mensagem" maxlength="2000" autocomplete="off" required placeholder="Escreva uma mensagem..." <?=empty($m['ativa'])?'disabled':''?>></div>
  <button class="btn gold" type="submit" <?=empty($m['ativa'])?'disabled':''?>>Enviar</button>
 </form><div id="chatStatus" class="small" role="status"></div>
</div>
<script>
(()=>{
 const box=document.getElementById('chatMessages'),form=document.getElementById('mesaChatForm'),target=document.getElementById('chatTarget'),actor=document.getElementById('chatActor'),status=document.getElementById('chatStatus');
 const mesaId=<?=json_encode($id)?>;let cursor=0,participantsLoaded=false,initial=true;
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function jsonResponse(res){const raw=await res.text();let j;try{j=JSON.parse(raw)}catch(e){if(res.status===403)throw new Error('403 Forbidden: o provedor bloqueou a requisição antes de chegar ao PHP. Confira regras WAF/ModSecurity e libere api/mensagens.php.');throw new Error('Resposta não JSON (HTTP '+res.status+'). Verifique a URL, redirecionamentos e logs do provedor.')}if(!res.ok&&!j.error)throw new Error('Erro HTTP '+res.status);return j}
 function addRow(m,legacy=false){const row=document.createElement('div');row.className='chat-row';row.dataset.id=m.id;row.dataset.legacy=legacy?'1':'0';row.dataset.from=m.remetente_tipo+':'+m.remetente_id;row.dataset.to=m.destinatario_tipo+':'+(m.destinatario_id||0);row.style.cssText='padding:8px 2px;border-bottom:1px solid #26364b';row.innerHTML='<b>'+esc(m.nome)+'</b> <span class="small">'+esc(m.criado_em)+'</span> <span class="tag">'+esc(legacy?'Geral (histórico)':m.destino_nome)+'</span><div style="white-space:pre-wrap;overflow-wrap:anywhere">'+esc(m.mensagem)+'</div>';box.appendChild(row)}
 function filter(){const t=target.value,a=actor.value,me=String(<?=json_encode((int)$u['id'])?>);for(const el of box.querySelectorAll('.chat-row')){const from=el.dataset.from,to=el.dataset.to;let show=t==='geral:0'?(to==='geral:0'||el.dataset.legacy==='1'):(el.dataset.legacy!=='1'&&((from===a&&to===t)||(from===t&&to===a)||(from==='usuario:'+me&&to===t)||(from===t&&to==='usuario:'+me)));el.style.display=show?'':'none'}}
 function opt(value,label){const o=document.createElement('option');o.value=value;o.textContent=label;return o}
 function setup(j){if(participantsLoaded)return;participantsLoaded=true;const me=Number(j.me);for(const u of j.participants.users)if(Number(u.id)!==me)target.appendChild(opt('usuario:'+u.id,'👤 '+u.nome));for(const p of j.participants.characters){target.appendChild(opt('personagem:'+p.id,'⚔ '+p.nome));if(Number(p.usuario_id)===me)actor.appendChild(opt('personagem:'+p.id,'⚔ '+p.nome))}for(const e of j.participants.entities){target.appendChild(opt('entidade:'+e.id,(e.categoria==='NPC'?'🧙 ':'🐉 ')+e.nome));if(j.gm||Number(e.usuario_id)===me)actor.appendChild(opt('entidade:'+e.id,(e.categoria==='NPC'?'🧙 ':'🐉 ')+e.nome))}if(!j.active){status.textContent='Mesa inativa: histórico disponível apenas para leitura.'}}
 async function load(){try{const res=await fetch('../api/mensagens.php?mesa_id='+mesaId+'&after='+cursor,{cache:'no-store'});const j=await jsonResponse(res);if(!j.ok)throw new Error(j.error||'Falha ao carregar');setup(j);if(initial){for(const m of j.legacy||[])addRow({...m,remetente_tipo:'usuario',remetente_id:m.usuario_id,destinatario_tipo:'geral',destinatario_id:0},true);initial=false}for(const m of j.messages||[])addRow(m);cursor=Number(j.cursor??cursor);filter();if(j.messages?.length)box.scrollTop=box.scrollHeight;}catch(e){status.textContent=e.message}}
 target.addEventListener('change',()=>{const [k,id]=target.value.split(':');document.getElementById('chatRecipientType').value=k;document.getElementById('chatRecipientId').value=id;filter()});
 actor.addEventListener('change',()=>{const [k,id]=actor.value.split(':');document.getElementById('chatSenderType').value=k;document.getElementById('chatSenderId').value=id;filter()});
 form.addEventListener('submit',async ev=>{ev.preventDefault();const input=document.getElementById('chatMessage');if(!input.value.trim())return;try{const res=await fetch('../api/mensagens.php',{method:'POST',body:new FormData(form)});const j=await jsonResponse(res);if(!j.ok)throw new Error(j.error||'Falha ao enviar');input.value='';status.textContent='Mensagem enviada.';await load()}catch(e){status.textContent=e.message}});
 load();setInterval(load,4000);
})();
</script>
<script>document.addEventListener('submit',async function(ev){const f=ev.target;if(!f.matches('.entity-pv-form'))return;ev.preventDefault();const btn=f.querySelector('button'),old=btn.textContent;btn.disabled=true;try{const res=await fetch(f.action,{method:'POST',body:new FormData(f),credentials:'same-origin'});const text=await res.text();let j;try{j=JSON.parse(text)}catch(e){throw new Error('Servidor não retornou JSON (HTTP '+res.status+')')}if(!j.ok)throw new Error(j.error||'Falha ao atualizar PV');btn.textContent='Salvo';setTimeout(()=>btn.textContent=old,1500)}catch(e){alert(e.message)}finally{btn.disabled=false}},true);</script>

<?php
$es=$pdo->prepare('SELECT e.id,e.nome,e.categoria,e.descricao,e.usuario_id,e.dados FROM entidades e JOIN entidade_mesas em ON em.entidade_id=e.id WHERE em.mesa_id=? ORDER BY e.categoria,e.nome');$es->execute([$id]);$creatures=$es->fetchAll();
?>
<div class="card section"><div class="section-title"><h2>🧙 NPCs e monstros participantes</h2><?php if($ehMestre):?><a class="btn" href="../entidades.php">Gerenciar NPCs e monstros</a><?php endif;?></div>
<?php if(!$creatures):?><p class="small">Nenhum NPC ou monstro associado a esta mesa.</p><?php endif;?>
<?php foreach($creatures as $c):?><div class="member-card"><b><?=h($c['nome'])?></b><span class="tag"><?=h($c['categoria'])?></span><?php if($ehMestre||(int)$c['usuario_id']===(int)$u['id']):?><span class="small"><?=h($c['descricao'])?></span><?php $stats=json_decode($c['dados']??'{}',true)?:[]; ?><form class="entity-pv-form" style="display:flex;gap:8px;align-items:end" method="post" action="entidade_pv.php"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="mesa_id" value="<?=$id?>"><input type="hidden" name="entidade_id" value="<?=(int)$c['id']?>"><label>PV atual <input class="input" style="max-width:100px" type="number" min="0" max="<?=max(0,(int)($stats['pv']??0))?>" name="pv_atual" value="<?=h($stats['pv_atual']??$stats['pv']??0)?>"></label><button class="btn smallbtn" type="submit">Atualizar PV</button><span class="small">Máximo: <?=h($stats['pv']??0)?></span></form><?php endif;?><?php if($ehMestre||(int)$c['usuario_id']===(int)$u['id']):?><a class="btn smallbtn" href="../entidade/editar.php?id=<?=$c['id']?>">Editar</a><?php endif;?></div><?php endforeach;?></div>
<div class="grid-2 section">
<div class="card"><div class="section-title"><h2>Jogadores e personagens</h2><span></span></div>
<?php if(!$ps):?><div class="empty">Nenhum personagem está associado à mesa.</div>
<?php else:foreach($ps as $p):$d=json_decode($p['dados'],true)?:[];?><div class="member-card section"><div class="hero"><?php if($p['imagem']):?><img class="avatar" src="<?=h($p['imagem'])?>"><?php endif;?><div><b><?=h($p['nome'])?></b><div class="small"><?=h($d['classe']??'')?> · Nível <?=h($d['nivel']??1)?> · Jogador: <?=h($p['jogador'])?></div><div class="small">PV <?=h($d['pv_atual']??0)?> / <?=h($d['pv_max']??0)?> · CA <?=h($d['ca']??10)?></div></div></div><a class="btn smallbtn" href="../personagem/editar.php?id=<?=$p['id']?>">Abrir ficha</a></div><?php endforeach;endif;?></div>
<div class="card"><div class="section-title"><h2>Membros</h2><span></span></div><?php if(!$members):?><div class="empty">Nenhum membro adicional.</div><?php else:foreach($members as $mm):?><div class="member-card"><span><?=h($mm['nome'])?></span><span class="tag"><?=h($mm['funcao'])?></span></div><?php endforeach;endif;?></div>
</div>

<div class="card section video-tabletop-card">
 <div class="section-title"><h2>Videoconferência da mesa</h2><span></span></div>
 <p class="small">Sala de áudio e vídeo para os participantes. Ao entrar, permita o acesso à webcam e ao microfone no navegador, conforme sua preferência.</p>
 <div class="video-room-actions">
  <a class="btn gold" href="<?=h('https://meet.jit.si/DNDManagerMesa'.$id)?>" target="_blank" rel="noopener noreferrer">🎥 Abrir sala com áudio e vídeo</a>
  <button class="btn" type="button" onclick="copyVideoRoom()">Copiar link da sala</button>
 </div>
 <div class="video-room-frame-wrap">
  <iframe title="Videoconferência da mesa <?=h($m['nome'])?>" src="<?=h('https://meet.jit.si/DNDManagerMesa'.$id)?>" allow="camera; microphone; fullscreen; display-capture; autoplay; clipboard-write" referrerpolicy="no-referrer" loading="lazy"></iframe>
 </div>
 <div class="small">A videoconferência usa o serviço externo Jitsi Meet e depende de conexão com a internet. A sala é identificada pelo número desta mesa; compartilhe o link apenas com os participantes.</div>
</div>

<div class="grid-2 section">
<div class="card">
<div class="section-title"><h2>Rolagem de dados</h2><span></span></div>
<div class="roll-tabs"><button type="button" class="roll-tab active" id="tabNumeric" onclick="setRollMode('numerico')">🎲 Dados D&D</button><button type="button" class="roll-tab" id="tabPoker" onclick="setRollMode('poker')">🂱 Dados Poker</button></div>
<div id="numericMode">
<p class="small">Dados disponíveis: d2, d4, d6, d8, d10, d12, d20 e d100, além dos dados Poker. A animação mostra cada dado e o resultado individual antes do total.</p>
<div class="grid-2 section"><div><label>Quantidade de dados</label><input class="input" id="numericQty" type="number" min="1" max="20" value="1" oninput="syncExpression()"></div><div><label>Modificador</label><input class="input" id="numericMod" type="number" value="0" oninput="syncExpression()"></div></div><div class="roll-dice"><?php foreach([2,4,6,8,10,12,20,100] as $n):?><button type="button" class="btn" onclick="rollDie(<?=$n?>)">d<?=$n?></button><?php endforeach;?></div>
<div class="grid-2 section"><div><label>Expressão</label><input class="input" id="expr" value="1d20 + 0" placeholder="2d20 + 5"></div><div><label>Personagem</label><select class="input" id="char"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="roll(document.getElementById('expr').value)">🎲 Rolar</button>
</div>

<div id="pokerMode" class="hidden">
<p class="small">Dado Poker de 6 faces: <b>Ás, K, Q, J, 10 e 9</b>. As cores seguem o padrão visual solicitado.</p>
<div class="poker-face-reference">
<div class="poker-ref poker-black"><span>🂱</span><b>Ás</b><small>Preto</small></div>
<div class="poker-ref poker-red"><span>🃞</span><b>K</b><small>Vermelho</small></div>
<div class="poker-ref poker-green"><span>🃝</span><b>Q</b><small>Verde</small></div>
<div class="poker-ref poker-blue"><span>🂻</span><b>J</b><small>Azul</small></div>
<div class="poker-ref poker-purple"><span>🃊</span><b>10</b><small>Roxo/Rosa</small></div>
<div class="poker-ref poker-orange"><span>🃉</span><b>9</b><small>Laranja/Amarelo</small></div>
</div>
<div class="grid-2 section"><div><label>Quantidade de dados Poker</label><input class="input" id="pokerQty" type="number" min="1" max="20" value="5"></div><div><label>Personagem</label><select class="input" id="pokerChar"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="rollPoker()">🃏 Rolar Poker</button><div id="pokerRerollControls" class="section hidden"><div class="notice">Escolha <b>0 a 2 dados</b> e clique em “Rolar novamente”. Essa segunda rolagem só pode ser usada uma vez.</div><button type="button" class="btn" id="rerollPokerBtn" onclick="rerollPoker()">🔄 Rolar novamente (0/2)</button></div>
</div>
<div id="rollResult" class="roll-result section"><div class="small">Resultado da rolagem</div><div id="numericDiceVisual" class="numeric-dice-visual"></div><div id="numericTotal">—</div></div>
<div id="pokerResult" class="poker-result hidden"></div>
</div>

<div class="card"><div class="section-title"><h2>Histórico de rolagens</h2><span></span></div><div class="dice-history" id="history">
<?php foreach($rolls as $r): $rv=json_decode($r['resultado_visual']??'',true)?:[]; $isPoker=($r['tipo']??'numerico')==='poker'; ?>
<div class="history-row"><div><b><?=h($isPoker ? ($rv['combinacao']??'Poker') : $r['resultado'])?></b> · <?=h($r['expressao'])?><div class="small"><?=h($r['usuario'])?><?php if($r['personagem']):?> · <?=h($r['personagem'])?><?php endif;?></div><?php if($isPoker&&isset($rv['faces'])):$initial=$rv['faces_iniciais']??$rv['faces'];$current=$rv['faces'];$changed=$rv['dados_rerrolados']??[];$sub=$rv['faces_substituidas']??array_map(fn($i)=>$initial[$i]??null,$changed);?>
<div class="poker-history-flow">
 <div class="poker-history-stage"><b>Inicial</b><div class="history-poker-faces"><?php foreach($initial as $f):?><img class="mini-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado <?=h($f['codigo'])?>" title="<?=h($f['nome'])?>"><?php endforeach;?></div></div>
 <div class="poker-history-stage"><b>Substituição</b><div class="history-poker-faces"><?php if(!empty($rv['rerrolado'])):foreach($sub as $f):if($f):?><img class="mini-poker-img selected-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado selecionado <?=h($f['codigo'])?>" title="Selecionado: <?=h($f['nome'])?>"><?php endif;endforeach;else:?><span class="small">—</span><?php endif;?></div></div>
 <div class="poker-history-stage"><b>Final</b><div class="history-poker-faces"><?php foreach($current as $f):?><img class="mini-poker-img final-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado final <?=h($f['codigo'])?>" title="Final: <?=h($f['nome'])?>"><?php endforeach;?></div></div>
</div><?php elseif(!$isPoker && isset($rv['faces'])): ?><div class="small"><?=h($r['detalhes'])?></div><div class="numeric-dice-visual history-numeric-dice"><?php foreach($rv['faces'] as $v): ?><div class="die-token"><img src="<?=h('../public/images/dice/d'.(int)($rv['lados']??6).'.svg')?>" alt="Dado d<?=h($rv['lados']??6)?>"><span><?=h($v)?></span><small>d<?=h($rv['lados']??6)?></small></div><?php endforeach; ?></div><?php else: ?><div class="small"><?=h($r['detalhes'])?></div><?php endif;?></div><span class="small"><?=h($r['criado_em'])?></span></div>
<?php endforeach;if(!$rolls):?><div class="empty">Nenhuma rolagem ainda.</div><?php endif;?></div></div>
</div>

<script>
const mesaId='<?= $id ?>';
const videoRoomUrl='<?=h('https://meet.jit.si/DNDManagerMesa'.$id)?>';
async function copyVideoRoom(){try{await navigator.clipboard.writeText(videoRoomUrl);alert('Link da sala copiado.');}catch(e){window.prompt('Copie o link da sala:',videoRoomUrl);}}
function setRollMode(mode){
 document.getElementById('numericMode').classList.toggle('hidden',mode!=='numerico');
 document.getElementById('pokerMode').classList.toggle('hidden',mode!=='poker');
 document.getElementById('tabNumeric').classList.toggle('active',mode==='numerico');
 document.getElementById('tabPoker').classList.toggle('active',mode==='poker');
 document.getElementById('rollResult').classList.toggle('hidden',mode==='poker');
 document.getElementById('pokerResult').classList.toggle('hidden',mode!=='poker');
}
function syncExpression(){const q=Math.max(1,Math.min(20,parseInt(document.getElementById('numericQty').value||1,10)));const mod=parseInt(document.getElementById('numericMod').value||0,10);const ex=document.getElementById('expr');const m=ex.value.match(/d(2|4|6|8|10|12|20|100)/i);if(m)ex.value=q+'d'+m[1]+(mod?(mod>0?' + ':' - ')+Math.abs(mod):'');}
function rollDie(sides){const q=Math.max(1,Math.min(20,parseInt(document.getElementById('numericQty').value||1,10)));const mod=parseInt(document.getElementById('numericMod').value||0,10);const expr=q+'d'+sides+(mod?(mod>0?' + ':' - ')+Math.abs(mod):'');document.getElementById('expr').value=expr;roll(expr);}
function pokerImagePath(face){const slug=(face?.classe||'poker-black').replace('poker-','');return '../public/images/poker/'+slug+'.svg';}
function pokerImg(face, cls='mini-poker-img'){
 const img=document.createElement('img');img.className=cls;img.src=pokerImagePath(face);img.alt='Dado '+(face?.codigo||'');img.title=face?.nome||face?.codigo||'';return img;
}
function historyStage(label, faces, extraClass=''){
 const stage=document.createElement('div');stage.className='poker-history-stage '+extraClass;
 const heading=document.createElement('b');heading.textContent=label;stage.appendChild(heading);
 const list=document.createElement('div');list.className='history-poker-faces';(faces||[]).forEach(f=>list.appendChild(pokerImg(f,'mini-poker-img '+extraClass)));stage.appendChild(list);return stage;
}
function renderHistoryFlow(container,j){
 const flow=document.createElement('div');flow.className='poker-history-flow';
 const initial=j.faces_iniciais||j.faces||[];const selected=(j.dados_rerrolados||[]).map(i=>(initial[i]));const final=j.faces||[];
 flow.appendChild(historyStage('Inicial',initial));
 const replacement=historyStage('Substituição',j.rerrolado?selected:[],'selected-poker-img');
 if(!j.rerrolado){const empty=document.createElement('span');empty.className='small';empty.textContent='—';replacement.querySelector('.history-poker-faces').appendChild(empty);}
 flow.appendChild(replacement);flow.appendChild(historyStage('Final',final,'final-poker-img'));container.appendChild(flow);
}
function addHistory(j, isPoker){
 const h=document.getElementById('history');const row=document.createElement('div');row.className='history-row';
 const left=document.createElement('div');const b=document.createElement('b');b.textContent=isPoker?(j.combinacao||'Poker'):j.resultado;left.appendChild(b);left.append(' · '+j.expressao);
 const small=document.createElement('div');small.className='small';small.textContent=(j.usuario||'')+(j.personagem?' · '+j.personagem:'');left.appendChild(small);
 if(isPoker)renderHistoryFlow(left,j);else{const d=document.createElement('div');d.className='small';d.textContent=j.detalhes||'';left.appendChild(d);const visual=document.createElement('div');visual.className='numeric-dice-visual history-numeric-dice';renderNumericDice(visual,j.faces||[],j.lados||6);left.appendChild(visual);}
 const time=document.createElement('span');time.className='small';time.textContent='agora';row.append(left,time);h.prepend(row);return row;
}
function dieImagePath(sides){return '../public/images/dice/d'+sides+'.svg';}
function renderNumericDice(target, faces, sides, animate=false){
 target.innerHTML='';(faces||[]).forEach((value,index)=>{const die=document.createElement('div');die.className='die-token'+(animate?' die-rolling':'');die.style.setProperty('--roll-delay',(index*65)+'ms');const img=document.createElement('img');img.src=dieImagePath(sides);img.alt='Imagem de dado d'+sides;img.onerror=()=>{img.onerror=null;img.src='../public/images/dice/d20.svg';};const num=document.createElement('span');num.textContent=value;num.setAttribute('aria-label','Resultado '+value);const label=document.createElement('small');label.textContent='d'+sides+' · '+(index+1);die.append(img,num,label);target.appendChild(die);if(animate)setTimeout(()=>die.classList.remove('die-rolling'),850+index*65);});
}
async function roll(expr){
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('expressao',expr);fd.append('personagem_id',document.getElementById('char').value);fd.append('modo','numerico');
 const button=document.querySelector('#numericMode .btn.gold');if(button){button.disabled=true;button.textContent='🎲 Rolando…';}
 try{const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}const m=expr.match(/^\d+d(2|4|6|8|10|12|20|100)/i);const sides=m?Number(m[1]):6;renderNumericDice(document.getElementById('numericDiceVisual'),j.faces,sides,true);document.getElementById('numericTotal').textContent='Total: '+j.resultado+(j.modificador?' (modificador '+(j.modificador>0?'+':'')+j.modificador+')':'');j.lados=sides;addHistory(j,false);const summary=document.createElement('div');summary.className='roll-script-summary';summary.textContent=expr+' → ['+(j.faces||[]).join(' · ')+']'+(j.modificador?' '+(j.modificador>0?'+':'−')+' '+Math.abs(j.modificador):'')+' = '+j.resultado;document.getElementById('numericTotal').appendChild(summary);}catch(e){alert('Não foi possível concluir a rolagem. Verifique a conexão e tente novamente.');}finally{if(button){button.disabled=false;button.textContent='🎲 Rolar';}}
}
let pokerToken=null,pokerRerollUsed=false,pokerHistoryRow=null;
function updatePokerHistoryRow(row,j){
 const left=row.firstElementChild;left.innerHTML='';const b=document.createElement('b');b.textContent=j.combinacao||'Poker';left.appendChild(b);left.append(' · '+j.expressao);
 const small=document.createElement('div');small.className='small';small.textContent=(j.usuario||'')+(j.personagem?' · '+j.personagem:'');left.appendChild(small);renderHistoryFlow(left,j);
}
function renderPoker(j){
 const box=document.getElementById('pokerResult');box.innerHTML='';box.classList.remove('hidden');
 const title=document.createElement('div');title.className='poker-combo';title.textContent=j.combinacao||'Rolagem Poker';box.appendChild(title);
 const current=document.createElement('div');current.className='poker-current-label';current.textContent=j.rerrolado?'Resultado atual após substituição':'Rolagem atual';box.appendChild(current);
 const cards=document.createElement('div');cards.className='poker-roll';
 (j.faces||[]).forEach((f,i)=>{const c=document.createElement('button');c.type='button';c.className='poker-card '+f.classe;c.dataset.index=i;const img=document.createElement('img');img.className='poker-die-image';img.src=pokerImagePath(f);img.alt='Dado Poker '+f.codigo;c.appendChild(img);const name=document.createElement('small');name.textContent=f.nome;c.appendChild(name);if(!pokerRerollUsed&&!j.rerrolado)c.onclick=()=>togglePokerSelection(c);cards.appendChild(c);});box.appendChild(cards);
 const sum=document.createElement('div');sum.className='small poker-sum';sum.textContent='Valor interno da rolagem: '+j.resultado;box.appendChild(sum);
 if(j.rerrolado){const note=document.createElement('div');note.className='small';note.textContent='Rerrolagem concluída. A rolagem final está exibida acima.';box.appendChild(note);}
 document.getElementById('pokerRerollControls').classList.toggle('hidden',!!j.rerrolado||pokerRerollUsed);updateRerollCount();
}
function togglePokerSelection(card){if(pokerRerollUsed)return;const selected=document.querySelectorAll('.poker-card.reroll-selected');if(!card.classList.contains('reroll-selected')&&selected.length>=2){alert('Você pode selecionar no máximo 2 dados.');return;}card.classList.toggle('reroll-selected');updateRerollCount();}
function updateRerollCount(){const n=document.querySelectorAll('.poker-card.reroll-selected').length;const b=document.getElementById('rerollPokerBtn');if(b)b.textContent='🔄 Rolar novamente ('+n+'/2)';}
async function rollPoker(){
 pokerRerollUsed=false;pokerToken=null;pokerHistoryRow=null;
 const qty=Math.max(1,Math.min(20,parseInt(document.getElementById('pokerQty').value||5,10)));document.getElementById('pokerQty').value=qty;
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('quantidade',qty);fd.append('personagem_id',document.getElementById('pokerChar').value);
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 pokerToken=j.token;renderPoker(j);pokerHistoryRow=addHistory(j,true);
}
async function rerollPoker(){
 if(pokerRerollUsed||!pokerToken)return;const selected=[...document.querySelectorAll('.poker-card.reroll-selected')].map(x=>Number(x.dataset.index));
 if(selected.length>2){alert('Escolha no máximo 2 dados.');return;}
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('quantidade',document.getElementById('pokerQty').value);fd.append('personagem_id',document.getElementById('pokerChar').value);fd.append('poker_token',pokerToken);fd.append('reroll_action','1');selected.forEach(i=>fd.append('reroll_indices[]',i));
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 pokerRerollUsed=true;pokerToken=null;renderPoker(j);if(pokerHistoryRow){updatePokerHistoryRow(pokerHistoryRow,j);}else{pokerHistoryRow=addHistory(j,true);}document.getElementById('pokerRerollControls').classList.add('hidden');
}

</script>
<?php bottom(); ?>
