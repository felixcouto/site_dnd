<?php
require_once __DIR__.'/../config/layout.php';
exigePapel(['mestre','admin']);
$u=usuario();$uid=(int)$u['id'];$id=(int)($_POST['id']??$_GET['id']??0);
$stmt=$pdo->prepare('SELECT m.*,u.nome AS mestre_nome FROM mesas m JOIN usuarios u ON u.id=m.mestre_id WHERE m.id=?');$stmt->execute([$id]);$mesa=$stmt->fetch(PDO::FETCH_ASSOC);
if(!$mesa||($u['tipo']!=='admin'&&(int)$mesa['mestre_id']!==$uid)){http_response_code(403);exit('Sem permissão para transferir esta mesa.');}
$notice='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!csrf_check((string)($_POST['csrf']??''))){http_response_code(403);exit('Token de segurança inválido.');}
 $novo=(int)($_POST['novo_mestre_id']??0);
 $q=$pdo->prepare("SELECT id,nome,tipo FROM usuarios WHERE id=? AND tipo IN ('mestre','admin')");$q->execute([$novo]);$dest=$q->fetch(PDO::FETCH_ASSOC);
 if(!$dest)$notice='Selecione um usuário com perfil mestre ou administrador.';
 elseif($novo===(int)$mesa['mestre_id'])$notice='O mestre selecionado já administra esta mesa.';
 else{
  try{
   $pdo->beginTransaction();
   $q=$pdo->prepare('UPDATE mesas SET mestre_id=? WHERE id=? AND mestre_id=?');$q->execute([$novo,$id,(int)$mesa['mestre_id']]);
   if($q->rowCount()!==1)throw new RuntimeException('A mesa foi alterada simultaneamente. Atualize e tente novamente.');
   // Preserve old GM as a member, when not already a member.
   $q=$pdo->prepare('SELECT 1 FROM mesa_membros WHERE mesa_id=? AND usuario_id=?');$q->execute([$id,(int)$mesa['mestre_id']]);
   if(!$q->fetchColumn()){$q=$pdo->prepare("INSERT INTO mesa_membros(mesa_id,usuario_id,funcao) VALUES(?,?,'jogador')");$q->execute([$id,(int)$mesa['mestre_id']]);}
   $pdo->commit();
   header('Location: ver.php?id='.$id);exit;
  }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();error_log('Transferência mesa: '.$e->getMessage());$notice='Não foi possível transferir a mesa. Consulte os logs do servidor.';}
 }
}
$q=$pdo->query("SELECT id,nome FROM usuarios WHERE tipo IN ('mestre','admin') ORDER BY nome");$mestres=$q->fetchAll(PDO::FETCH_ASSOC);
top('Transferir mesa'); ?>
<div class="card section"><h1>Transferir mesa</h1><p><b><?=h($mesa['nome'])?></b> · Mestre atual: <?=h($mesa['mestre_nome'])?></p>
<p class="small">A transferência altera o mestre responsável pela mesa. Os personagens, membros, NPCs, monstros e histórico de chat permanecem associados à mesa.</p>
<?php if($notice):?><div class="notice"><?=h($notice)?></div><?php endif;?>
<form method="post"><input type="hidden" name="id" value="<?=$id?>"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Novo mestre</label><select class="input" name="novo_mestre_id" required><option value="">Selecione</option><?php foreach($mestres as $m):if((int)$m['id']===(int)$mesa['mestre_id'])continue;?><option value="<?=(int)$m['id']?>"><?=h($m['nome'])?></option><?php endforeach;?></select><p><button class="btn gold" type="submit" onclick="return confirm('Confirmar transferência da mesa para outro mestre?')">Confirmar transferência</button> <a class="btn" href="ver.php?id=<?=$id?>">Cancelar</a></p></form></div>
<?php bottom(); ?>
