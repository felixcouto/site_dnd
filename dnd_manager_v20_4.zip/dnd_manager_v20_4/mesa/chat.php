<?php
require __DIR__.'/../api/mensagens.php';
