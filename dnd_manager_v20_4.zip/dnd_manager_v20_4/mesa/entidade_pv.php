<?php
ob_start(); ini_set('display_errors','0');
require_once __DIR__.'/../config/auth.php'; require_once __DIR__.'/../config/password.php';
function out($data,$status=200){while(ob_get_level())ob_end_clean();http_response_code($status);header('Content-Type: application/json; charset=utf-8');header('Cache-Control: no-store');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
try{
 $u=usuario();if(!$u)out(['ok'=>false,'error'=>'Sessão expirada'],401);
 if($_SERVER['REQUEST_METHOD']!=='POST'||!csrf_check((string)($_POST['csrf']??'')))out(['ok'=>false,'error'=>'Requisição inválida'],403);
 $mid=(int)($_POST['mesa_id']??0);$eid=(int)($_POST['entidade_id']??0);$pv=(int)($_POST['pv_atual']??-1);
 $q=$pdo->prepare('SELECT e.usuario_id,e.dados,m.mestre_id,m.ativa FROM entidades e JOIN entidade_mesas em ON em.entidade_id=e.id JOIN mesas m ON m.id=em.mesa_id WHERE e.id=? AND m.id=?');$q->execute([$eid,$mid]);$e=$q->fetch();
 if(!$e||($u['tipo']!=='admin'&&(int)$e['usuario_id']!==(int)$u['id']&&(int)$e['mestre_id']!==(int)$u['id']))out(['ok'=>false,'error'=>'Sem permissão'],403);
 if(!(int)$e['ativa'])out(['ok'=>false,'error'=>'Mesa inativa'],409);
 $d=json_decode($e['dados']??'{}',true);$d=is_array($d)?$d:[];$max=max(0,(int)($d['pv']??0));if($pv<0||$pv>$max)out(['ok'=>false,'error'=>'PV fora do intervalo'],422);
 $d['pv_atual']=$pv;$q=$pdo->prepare('UPDATE entidades SET dados=? WHERE id=?');$q->execute([json_encode($d,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE),$eid]);out(['ok'=>true,'pv_atual'=>$pv]);
}catch(Throwable $e){error_log('entidade_pv: '.$e->getMessage());out(['ok'=>false,'error'=>'Erro ao salvar PV'],500);}
