# D&D Manager V20.4

## Atualizações
- Menu NPC's e Monstros e rodapé V20.4.
- Histórico de versões em ordem decrescente, com V1 ao final.
- Transferência de mestre da mesa (mestre atual ou administrador), com confirmação e proteção CSRF; mantém jogadores, personagens e conversas.
- Chat privado: mensagens disponíveis a ambos os participantes, inclusive quando representados por personagens, NPCs ou monstros. Filtro considera todas as identidades controladas pelo usuário.
- XP permanece acumulado e usa a progressão padrão de D&D 5e (independente de classe/subclasse): 300 XP para nível 2, 900 XP para nível 3 etc.

## Instalação
1. Faça backup do banco e dos arquivos da V20.3.
2. Substitua os arquivos e preserve as credenciais em config/conexao.php.
3. Execute database/migracao_v20_3_para_v20_4.sql (não há mudanças de estrutura).
4. Teste com dois usuários distintos, em duas sessões/navegadores, e valide a transferência de mesa.

## Limitações
Sem testes integrados na hospedagem real. O chat usa requisições periódicas; não usa WebSockets.
