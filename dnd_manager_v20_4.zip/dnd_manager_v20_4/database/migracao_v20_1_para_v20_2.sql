-- D&D Manager V20.1 -> V20.2 (MariaDB/MySQL)
-- Faça backup antes de aplicar. Preserve todas as tabelas e registros existentes.
-- Execute APÓS a migração da V20.1. Sem FKs para compatibilidade com MyISAM legado.
CREATE TABLE IF NOT EXISTS entidades (
 id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT NOT NULL,
 categoria ENUM('NPC','Monstro') NOT NULL,
 nome VARCHAR(190) NOT NULL,
 descricao TEXT NULL,
 dados LONGTEXT NULL,
 criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 atualizado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_entidades_usuario (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS entidade_mesas (
 entidade_id INT NOT NULL,
 mesa_id INT NOT NULL,
 PRIMARY KEY (entidade_id,mesa_id),
 KEY idx_entidade_mesas_mesa (mesa_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
-- O histórico da V20/V20.1 é mantido sem alteração; conversas novas usam tabela separada.
CREATE TABLE IF NOT EXISTS mesa_chat_v2 (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 mesa_id INT NOT NULL,
 usuario_id INT NOT NULL,
 remetente_tipo ENUM('usuario','personagem','entidade') NOT NULL DEFAULT 'usuario',
 remetente_id INT NOT NULL,
 destinatario_tipo ENUM('geral','usuario','personagem','entidade') NOT NULL DEFAULT 'geral',
 destinatario_id INT NULL,
 mensagem TEXT NOT NULL,
 criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 KEY idx_chat_v2_mesa (mesa_id,id),
 KEY idx_chat_v2_remetente (remetente_tipo,remetente_id),
 KEY idx_chat_v2_destinatario (destinatario_tipo,destinatario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
