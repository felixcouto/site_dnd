-- D&D Manager V20.3 → V20.4
-- Não há alteração estrutural: transferência utiliza mesas.mestre_id; chat mantém mesa_chat_v2.
-- Execute antes as migrações da V20.2 e V20.3, se ainda não aplicadas.
SELECT 1 AS migracao_v20_4_ok;
