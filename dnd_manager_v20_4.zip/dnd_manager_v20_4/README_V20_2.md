# D&D Manager V20.2.0

## Instalação
1. Faça backup do banco e dos arquivos da versão anterior.
2. Copie os arquivos da pasta `dnd_manager_v20_2` para a hospedagem; configure `config/conexao.php`.
3. Execute `database/migracao_v20_1_para_v20_2.sql` no banco usado pela aplicação.
4. Acesse Mesas > Abrir mesa > Chat; para NPCs/monstros acesse o menu NPCs e monstros.

## Chat e privacidade
- Geral: todos os participantes da mesa.
- Privado: destinatário usuário ou personagem; somente emissor e destinatário (dono do personagem) veem o histórico. NPCs e monstros são controlados pelo mestre.
- A seleção de identidade do remetente é limitada às fichas do usuário; apenas o mestre pode enviar como NPC/monstro.
- O histórico legado `mesa_chat` é exibido no canal geral; as novas mensagens ficam em `mesa_chat_v2`.
- Acesso a mensagens exige login e participação na mesa. A mesa inativa permite apenas leitura.

## Limitações
- O sistema não contém transcrição de bestiários protegidos por direitos autorais; NPCs e monstros podem ser criados manualmente ou importados via JSON com dados próprios ou licenciados.
- Os catálogos D&D 2024 da V20.1 foram preservados. Não se afirma sincronização integral com o aplicativo externo.
- Não houve teste de ponta a ponta com banco real. Execute os testes de aceitação no seu servidor.
- A data exata da V1 não foi verificada.
