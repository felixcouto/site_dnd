# D&D Manager V20.3

## Implantação
1. Faça backup do código e do banco.
2. Preserve os dados de conexão de `config/conexao.php` do servidor atual.
3. Envie os arquivos, respeitando a estrutura de diretórios.
4. Aplique a migração V20.2 se ainda não aplicada. A migração V20.3 é documental, sem DDL obrigatório.
5. Abra uma mesa ativa, faça GET e POST em `api/mensagens.php` e verifique o histórico.

## Erro 403 / HTML em vez de JSON
O novo endpoint é `api/mensagens.php`. Caso o provedor devolva uma página 403 antes da execução do PHP, a aplicação não pode contornar regras de segurança do servidor: solicite ao suporte a liberação da rota POST, do ModSecurity/WAF, verifique permissões de arquivos e diretórios e eventuais regras .htaccess. Evite desligar globalmente o WAF.

## Segurança
Participantes veem apenas nome, categoria, criador e mesas de NPCs e monstros. O criador e o mestre podem ajustar PV atual na mesa. Para dados completos, o editor permanece restrito ao criador/admin; mestres que não criaram a entidade podem gerenciar PV em sua mesa.

## Limites de validação
Verificação sintática PHP e integridade do ZIP não equivalem a testes com banco, sessões e políticas do provedor de hospedagem.
