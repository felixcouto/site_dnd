# D&D Manager V17

## Novidades
- Dados numéricos compactos: as imagens dos dados ocupam aproximadamente 10% da faixa de resultados em desktop, tanto no resultado atual quanto no histórico; em telas pequenas, o tamanho se adapta para preservar a legibilidade.
- SVGs locais para d2, d3, d4, d5, d6, d7, d8, d9, d10, d12, d20 e d100.
- Videoconferência de mesa com áudio e vídeo por Jitsi Meet, incorporada na página da mesa, com opção de abrir a sala em nova aba e copiar o link. O navegador solicitará permissão para webcam e microfone.

## Instalação
1. Extraia o ZIP no servidor PHP.
2. Mantenha a configuração existente em `config/conexao.php`.
3. Em atualização, preserve o banco existente; não há migração SQL para esta versão.
4. A videoconferência exige internet e acesso ao serviço externo `meet.jit.si`; o serviço externo pode ter suas próprias condições e controles de privacidade.

## Observações
A rolagem continua sendo processada pelo backend PHP, e a animação é apenas visual. A sala Jitsi é gerada a partir do ID da mesa; compartilhe o endereço somente com os participantes autorizados.
