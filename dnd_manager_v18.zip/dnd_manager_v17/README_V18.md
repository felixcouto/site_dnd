# D&D Manager V18

## Base de atualização
Esta versão parte do pacote V17 e usa como parâmetro documental o arquivo `Texto colado.txt` fornecido, cuja versão de referência mais recente é 3.3.8 (19/10/2026). O arquivo original completo foi incluído como `HISTORICO_REFERENCIA.txt`, sem remover as notas anteriores.

## Alterações da V18
- Rodapé global atualizado para **D&D Manager V18 · Versão 18.0.0**, com link para o histórico de versões.
- Rolagem numérica limitada aos dados solicitados: d2, d4, d6, d8, d10, d12, d20 e d100.
- Dados Poker mantidos como modo separado, incluindo rerrolagem e histórico Inicial → Substituição → Final.
- Validação do backend atualizada para rejeitar expressões com dados não permitidos (como d3, d5, d7 e d9).
- Seletor de dados, detecção da expressão e botões rápidos atualizados para usar exatamente os oito tipos permitidos.
- Criado `HISTORICO_VERSOES.txt`, com as notas de versões do D&D Manager disponíveis no projeto e a íntegra das notas de referência.

## Instalação
1. Faça backup dos arquivos e do banco.
2. Extraia o ZIP sobre uma cópia do projeto ou substitua os arquivos da instalação.
3. Mantenha a configuração existente em `config/conexao.php` e o banco atual.
4. Não é necessária migração SQL para as mudanças da V18.

## Validação
A validação desta entrega inclui lint PHP e integridade do ZIP. O teste integrado requer ambiente de execução PHP/MySQL real.
