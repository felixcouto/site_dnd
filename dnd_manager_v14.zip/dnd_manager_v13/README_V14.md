# D&D Manager V14

## Atualizações
- Rolagem visual para d4, d6, d8, d10, d12, d20 e d100 com silhuetas SVG locais específicas por tipo.
- Cada dado rolado é mostrado individualmente, com face numérica e identificação do tipo/posição. A quantidade visual corresponde ao número de dados da expressão.
- Resultado atual mostra os dados e o total com modificador separado.
- Histórico de rolagens numéricas mostra visualmente todos os dados, além da expressão e detalhes.
- Mantida a rolagem Poker da V13, incluindo imagens, seleção de até dois dados e histórico em três etapas.
- Não exige migração de banco de dados.

## Validação
A validação realizada nesta entrega é estática (sintaxe PHP/JS e integridade do ZIP). Execute também os testes integrados no ambiente PHP/MySQL antes de publicar.
