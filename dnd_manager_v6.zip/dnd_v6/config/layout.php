<?php
require_once __DIR__.'/auth.php';
function top($title='D&D Manager'){
 $script=$_SERVER['SCRIPT_NAME']??'';
 $base=(str_contains($script,'/mesa/')||str_contains($script,'/personagem/')||str_contains($script,'/admin/')||str_contains($script,'/api/'))?'../':'';
 $u=usuario();
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?></title><link rel="stylesheet" href="<?=$base?>public/style.css"></head><body>
<nav class="nav"><a class="brand" href="<?=$base?>dashboard.php">⚔ D&D Manager</a><div class="navlinks navlinks-spaced"><a href="<?=$base?>dashboard.php">Início</a>&nbsp;<a href="<?=$base?>personagens.php">Personagens</a>&nbsp;<a href="<?=$base?>mesas.php">Mesas</a>&nbsp;<?php if($u&&in_array($u['tipo'],['mestre','admin'])): ?><a href="<?=$base?>admin/usuarios.php">Admin</a>&nbsp;<?php endif;?><?php if($u&&$u['tipo']==='admin'): ?><a href="<?=$base?>admin/mesas.php">Todas as mesas</a>&nbsp;<?php endif;?></div><span class="spacer"></span><?php if($u):?><span class="user-context"><span class="user-label">Jogador:</span>&nbsp;<span class="userpill"><?=h($u['nome'])?> <b> &mdash; <b><?=h($u['tipo'])?></b></span></span><a class="logout" href="<?=$base?>logout.php">Sair</a><?php endif;?></nav><main class="wrap">
<?php
}
function bottom(){
?>
</main></body></html>
<?php
}
function msg($m){if($m)echo '<div class="notice">'.h($m).'</div>';}
?>
