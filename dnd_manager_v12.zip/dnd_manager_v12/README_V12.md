# D&D Manager V12

## Ajustes nos dados Poker
- Exibição dos resultados com imagens próprias dos seis dados Poker, tanto na rolagem atual quanto no histórico.
- Seleção visual dos dados que serão rerrolados, limitada a dois.
- A rerrolagem atualiza a exibição sem criar uma segunda linha no histórico.
- O histórico preserva a face original e mostra a face nova ao lado, na mesma linha, com indicação da atualização.
- As imagens são arquivos SVG locais em `public/images/poker/`, sem dependência de serviços externos.

Não é necessária migração de banco de dados em relação à V11.
