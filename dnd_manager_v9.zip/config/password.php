<?php
require_once __DIR__.'/conexao.php';

if (!function_exists('csrf_token')) {
    function csrf_token(){
        if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
        return $_SESSION['csrf'];
    }
    function csrf_check($token){
        return is_string($token) && !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $token);
    }
}
function app_url($path=''){
    $base = defined('APP_URL') ? rtrim(APP_URL,'/') : '';
    return $base . '/' . ltrim($path,'/');
}
function criar_token_senha($usuarioId){
    global $pdo;
    $pdo->prepare('UPDATE recuperacao_senha SET usado_em=NOW() WHERE usuario_id=? AND usado_em IS NULL')->execute([$usuarioId]);
    $raw = bin2hex(random_bytes(32));
    $hash = hash('sha256',$raw);
    $s=$pdo->prepare('INSERT INTO recuperacao_senha(usuario_id,token_hash,expira_em) VALUES(?,?,DATE_ADD(NOW(),INTERVAL 1 HOUR))');
    $s->execute([$usuarioId,$hash]);
    return $raw;
}
function buscar_token_senha($raw){
    global $pdo;
    if (!is_string($raw) || !preg_match('/^[a-f0-9]{64}$/',$raw)) return null;
    $hash=hash('sha256',$raw);
    $s=$pdo->prepare('SELECT * FROM recuperacao_senha WHERE token_hash=? AND usado_em IS NULL AND expira_em>NOW() LIMIT 1');
    $s->execute([$hash]);
    return $s->fetch() ?: null;
}
function marcar_token_usado($id){
    global $pdo;
    $pdo->prepare('UPDATE recuperacao_senha SET usado_em=NOW() WHERE id=?')->execute([$id]);
}
function enviar_link_recuperacao($email,$nome,$token){
    $url=app_url('redefinir_senha.php?token='.rawurlencode($token));
    $assunto='D&D Manager - Redefinição de senha';
    $corpo="Olá, {$nome}!\n\nRecebemos uma solicitação para redefinir a senha da sua conta no D&D Manager.\n\nUse o link abaixo em até 1 hora:\n{$url}\n\nSe você não solicitou a redefinição, ignore esta mensagem.\n\nD&D Manager";
    $from=defined('MAIL_FROM') ? MAIL_FROM : 'no-reply@localhost';
    $headers="From: {$from}\r\nContent-Type: text/plain; charset=UTF-8\r\n";
    return @mail($email,$assunto,$corpo,$headers);
}
