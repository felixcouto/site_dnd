<?php require_once __DIR__.'/conexao.php';
function loga($acao,$alvo='',$id=null){global $pdo;$u=usuario();$s=$pdo->prepare('INSERT INTO logs(usuario_id,acao,alvo,alvo_id) VALUES(?,?,?,?)');$s->execute([$u['id']??null,$acao,$alvo,$id]);}
function temMesa($mesa,$uid){global $pdo;$s=$pdo->prepare('SELECT 1 FROM mesa_membros WHERE mesa_id=? AND usuario_id=? UNION SELECT 1 FROM mesas WHERE id=? AND mestre_id=?');$s->execute([$mesa,$uid,$mesa,$uid]);return (bool)$s->fetchColumn();}
?>
