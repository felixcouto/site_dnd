# D&D Manager V8

V8 baseada na V5, com foco em segurança e recuperação de acesso.

## Novidades
- “Esqueci minha senha” na tela de login.
- Geração de token aleatório de 32 bytes.
- Apenas o hash SHA-256 do token é armazenado no banco.
- Token válido por 1 hora.
- Token de uso único.
- Tokens anteriores do mesmo usuário são invalidados ao solicitar novo link.
- Resposta genérica na solicitação para evitar descoberta de e-mails cadastrados.
- Redefinição por link enviado por `mail()` do PHP.
- Alteração de senha para usuário autenticado em “Minha conta”.
- Validação da senha atual na alteração autenticada.
- Senha mínima de 8 caracteres.
- `password_hash()`/`password_verify()` mantidos.
- Registro das alterações/solicitações no sistema de logs.
- Campo `senha_alterada_em`.
- Proteção CSRF nos formulários de recuperação e alteração.

## Instalação / atualização
Para banco existente, execute:

`database/migracao_v8.sql`

Configure em `config/conexao.php`:

- `APP_URL`: URL pública do sistema, sem barra final.
- `MAIL_FROM`: remetente permitido pelo servidor de e-mail.

Exemplo:

`define('APP_URL','https://seudominio.com/dnd_manager');`

`define('MAIL_FROM','no-reply@seudominio.com');`

Em hospedagem real, o servidor PHP precisa estar configurado para envio de e-mail. Em ambientes locais, `mail()` normalmente não entrega mensagens sem um MTA/SMTP configurado.

## Fluxo “Esqueci minha senha”
1. Usuário informa o e-mail.
2. O sistema sempre apresenta a mesma mensagem, exista ou não a conta.
3. Se a conta existir e estiver ativa, é criado um token aleatório.
4. O banco guarda somente o hash do token.
5. O link expira em 1 hora.
6. O usuário define a nova senha.
7. O token é marcado como utilizado e os demais tokens pendentes são invalidados.
8. O usuário retorna ao login.

## Segurança
A V8 não armazena senhas em texto puro e não coloca a senha no link de recuperação. Para produção, recomenda-se também HTTPS, configuração de SPF/DKIM/DMARC, limitação de requisições no endpoint de recuperação e envio via SMTP transacional.
