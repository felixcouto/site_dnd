<?php
require 'config/layout.php';
if(usuario()){header('Location: dashboard.php');exit;}
$mensagem='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!csrf_check($_POST['csrf']??'')){ $mensagem='Solicitação inválida. Atualize a página e tente novamente.'; }
    else {
        $email=trim($_POST['email']??'');
        if(filter_var($email,FILTER_VALIDATE_EMAIL)){
            $s=$pdo->prepare('SELECT id,nome,email FROM usuarios WHERE email=? AND ativo=1 LIMIT 1');
            $s->execute([$email]); $u=$s->fetch();
            if($u){
                $token=criar_token_senha($u['id']);
                enviar_link_recuperacao($u['email'],$u['nome'],$token);
                loga('solicitacao_recuperacao','usuario',$u['id']);
            }
        }
        $mensagem='Se existir uma conta ativa para esse e-mail, enviaremos instruções para redefinição da senha.';
    }
}
top('Esqueci minha senha');
?>
<div style="max-width:500px;margin:70px auto"><div class="card"><h1>Esqueci minha senha</h1><p class="small">Informe o e-mail cadastrado. Por segurança, a mensagem abaixo é igual exista ou não uma conta.</p>
<?php if($mensagem):?><div class="notice"><?=h($mensagem)?></div><?php endif;?>
<form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>E-mail</label><input class="input" type="email" name="email" autocomplete="email" required><button class="btn gold" type="submit">Enviar instruções</button></form>
<hr><a class="btn" href="index.php">Voltar para o login</a></div></div>
<?php bottom(); ?>
