<?php
require 'config/layout.php';
if(usuario()){header('Location: dashboard.php');exit;}
$token=$_GET['token']??$_POST['token']??'';
$rec=buscar_token_senha($token);
$erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!$rec) $erro='O link é inválido, já foi utilizado ou expirou.';
    elseif(!csrf_check($_POST['csrf']??'')) $erro='Solicitação inválida. Atualize a página e tente novamente.';
    else {
        $senha=$_POST['senha']??''; $confirm=$_POST['confirmacao']??'';
        if(strlen($senha)<8) $erro='A nova senha deve possuir pelo menos 8 caracteres.';
        elseif($senha!==$confirm) $erro='A confirmação da senha não coincide.';
        else {
            $pdo->beginTransaction();
            try{
                $h=password_hash($senha,PASSWORD_DEFAULT);
                $pdo->prepare('UPDATE usuarios SET senha=?,senha_alterada_em=NOW() WHERE id=?')->execute([$h,$rec['usuario_id']]);
                marcar_token_usado($rec['id']);
                $pdo->prepare('UPDATE recuperacao_senha SET usado_em=NOW() WHERE usuario_id=? AND usado_em IS NULL')->execute([$rec['usuario_id']]);
                $pdo->commit();
                header('Location: index.php?senha=alterada'); exit;
            }catch(Throwable $e){$pdo->rollBack();$erro='Não foi possível alterar a senha. Tente novamente.';}
        }
    }
}
top('Redefinir senha');
?>
<div style="max-width:500px;margin:70px auto"><div class="card"><h1>Redefinir senha</h1><?php if($erro):?><div class="notice danger-notice"><?=h($erro)?></div><?php endif;?><?php if($rec):?><p class="small">Crie uma nova senha para sua conta. O link é válido por 1 hora e só pode ser utilizado uma vez.</p><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><input type="hidden" name="token" value="<?=h($token)?>"><label>Nova senha</label><input class="input" type="password" name="senha" minlength="8" autocomplete="new-password" required><label>Confirmar nova senha</label><input class="input" type="password" name="confirmacao" minlength="8" autocomplete="new-password" required><button class="btn gold" type="submit">Alterar senha</button></form><?php else:?><p>O link de recuperação é inválido, já foi utilizado ou expirou.</p><a class="btn gold" href="esqueci_senha.php">Solicitar novo link</a><?php endif;?></div></div>
<?php bottom(); ?>
