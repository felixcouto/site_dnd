<?php
require 'config/layout.php';
exigeLogin();
$u=usuario(); $ok=''; $erro='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 if(!csrf_check($_POST['csrf']??'')) $erro='Solicitação inválida.';
 else {
  $atual=$_POST['senha_atual']??''; $nova=$_POST['nova_senha']??''; $conf=$_POST['confirmacao']??'';
  if(!password_verify($atual,$u['senha'])) $erro='A senha atual está incorreta.';
  elseif(strlen($nova)<8) $erro='A nova senha deve possuir pelo menos 8 caracteres.';
  elseif($nova!==$conf) $erro='A confirmação da nova senha não coincide.';
  elseif(password_verify($nova,$u['senha'])) $erro='A nova senha deve ser diferente da senha atual.';
  else {
   $h=password_hash($nova,PASSWORD_DEFAULT); $pdo->prepare('UPDATE usuarios SET senha=?,senha_alterada_em=NOW() WHERE id=?')->execute([$h,$u['id']]);
   loga('alteracao_senha','usuario',$u['id']); $ok='Senha alterada com sucesso.'; $u=usuario();
  }
 }
}
top('Minha conta');
?>
<div style="max-width:600px;margin:50px auto"><div class="card"><h1>Minha conta</h1><p class="small">Usuário: <?=h($u['nome'])?> · <?=h($u['email'])?></p><?php if($ok):?><div class="notice success-notice"><?=h($ok)?></div><?php endif;?><?php if($erro):?><div class="notice danger-notice"><?=h($erro)?></div><?php endif;?><form method="post"><input type="hidden" name="csrf" value="<?=h(csrf_token())?>"><label>Senha atual</label><input class="input" type="password" name="senha_atual" autocomplete="current-password" required><label>Nova senha</label><input class="input" type="password" name="nova_senha" minlength="8" autocomplete="new-password" required><label>Confirmar nova senha</label><input class="input" type="password" name="confirmacao" minlength="8" autocomplete="new-password" required><p class="small">Use pelo menos 8 caracteres. O sistema armazena somente o hash da senha.</p><button class="btn gold">Alterar senha</button></form></div></div>
<?php bottom(); ?>
