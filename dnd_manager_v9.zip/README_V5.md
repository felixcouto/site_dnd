# D&D Manager V5

V5 do D&D Manager baseada funcionalmente no fluxo público do projeto ZaitBr-bit/D-D_2024, mantendo a arquitetura PHP/MySQL do projeto anterior. O repositório de referência informa criação em 7 passos, escolhas filtradas por classe/espécie/antecedente, ficha em mesa, descanso, evolução, magias, inventário e importação/exportação. A V5 adapta esses conceitos à arquitetura do Manager, sem copiar o código do repositório.

## Novidades
- Assistente de criação/edição em 7 etapas.
- Catálogo local `dados/catalogo_v5.php` para classes, subclasses, espécies, origens, talentos, equipamentos, magias, perícias e apêndices.
- Regras derivadas recalculadas no salvamento: modificadores, bônus de proficiência, resistências e perícias.
- Classe define atributo principal, dado de vida, resistências e conjunto de perícias disponíveis.
- Origem, talentos, equipamentos e magias ficam associados à ficha.
- Controle de condições e recursos.
- Correção do bug de PV atual: existe uma única entrada para PV atual, evitando conflito entre `pv_atual` e `pv_atual2`.
- Compatibilidade com JSON das versões anteriores; campos desconhecidos são preservados.
- Migração V5 opcional para histórico de snapshots.
- Dados Poker da V4 permanecem funcionando.

## Referência funcional
O projeto público ZaitBr-bit/D-D_2024 informa atualmente um assistente de 7 passos, regras embutidas, 12 classes, 48 subclasses, 11 espécies, 16 antecedentes, talentos, magias, equipamento, PDF e importação/exportação. A V5 usa essa organização como referência de UX e modelo de dados, mas continua independente.

## Instalação
1. Extraia os arquivos no servidor PHP.
2. Configure `config/conexao.php`.
3. Para banco existente, execute `database/migracao_v5.sql`.
4. Acesse o sistema e abra `personagem/editar.php` para criar ou editar.
5. A ficha utiliza `schema_versao = 5` no JSON.

## Observação sobre conteúdo
O catálogo incluído é uma base funcional e extensível. Para conteúdo integral de livros protegidos, recomenda-se carregar apenas conteúdo que você tenha direito de usar ou conteúdo disponibilizado sob licença aplicável, como SRD.
