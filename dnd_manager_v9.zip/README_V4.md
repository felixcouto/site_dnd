# D&D Manager V4

A V4 acrescenta ao sistema de rolagens da V3 um modo **Dados Poker**.

## Dados Poker
Cada dado possui seis faces, sem números convencionais:

1. Ás (A)
2. Rei (K)
3. Dama (Q)
4. Valete (J)
5. 10
6. 9

O sistema apresenta as faces com uma identificação visual por cor:

- Ás: preto
- Rei (K): vermelho
- Dama (Q): verde
- Valete (J): azul
- 10: roxo/rosa
- 9: laranja/amarelo

A interface mostra a face, o símbolo de carta, o nome e a cor. A rolagem padrão é de **5 dados**, mas o usuário pode lançar de 1 a 20 dados.

Quando são lançados exatamente 5 dados, o sistema identifica combinações: Quina, Quadra, Full House, Trinca, Dois pares, Um par ou Carta alta.

## Compatibilidade
O modo D&D tradicional continua aceitando d4, d6, d8, d10, d12, d20 e d100, além de expressões como `2d20 + 5`.

O histórico registra o modo da rolagem e, no caso Poker, os resultados visuais em JSON para permitir futura exportação e reprocessamento.

## Banco de dados
Para uma instalação V3 já existente, execute `database/migracao_v4_poker.sql`. Ela adiciona apenas:

- `rolagens.tipo`
- `rolagens.resultado_visual`
- índice para consulta por mesa/tipo/data

Nenhum dado existente é apagado.
