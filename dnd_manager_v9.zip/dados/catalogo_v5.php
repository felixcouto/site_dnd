<?php
/* Catálogo V5: estrutura compatível com D&D 2024/SRD. Conteúdo textual pode ser ampliado por JSON externo sem alterar a ficha. */
return [
 'classes'=>[
  ['id'=>'barbaro','nome'=>'Bárbaro','dado'=>'d12','atributo'=>'forca','resistencias'=>['forca','constituicao'],'pericias'=>['adestrar_animais','atletismo','intimidacao','natureza','percepcao','sobrevivencia'],'subclasses'=>['Berserker','Coração Selvagem','Árvore do Mundo','Fanático']],
  ['id'=>'bardo','nome'=>'Bardo','dado'=>'d8','atributo'=>'carisma','resistencias'=>['destreza','carisma'],'pericias'=>['acrobacia','adestrar_animais','arcanismo','atletismo','enganacao','historia','intuicao','intimidacao','investigacao','medicina','natureza','percepcao','atuacao','persuasao','religiao','prestidigitacao','furtividade','sobrevivencia'],'subclasses'=>['Dança','Glamour','Conhecimento','Valor']],
  ['id'=>'clerigo','nome'=>'Clérigo','dado'=>'d8','atributo'=>'sabedoria','resistencias'=>['sabedoria','carisma'],'pericias'=>['historia','intuicao','medicina','persuasao','religiao'],'subclasses'=>['Vida','Luz','Trapaça','Guerra']],
  ['id'=>'druida','nome'=>'Druida','dado'=>'d8','atributo'=>'sabedoria','resistencias'=>['inteligencia','sabedoria'],'pericias'=>['arcanismo','adestrar_animais','intuicao','medicina','natureza','percepcao','religiao','sobrevivencia'],'subclasses'=>['Terra','Lua','Mar','Estrelas']],
  ['id'=>'guerreiro','nome'=>'Guerreiro','dado'=>'d10','atributo'=>'forca','resistencias'=>['forca','constituicao'],'pericias'=>['acrobacia','adestrar_animais','atletismo','historia','intuicao','intimidacao','percepcao','sobrevivencia'],'subclasses'=>['Mestre de Batalha','Campeão','Cavaleiro Místico','Guerreiro Psiônico']],
  ['id'=>'monge','nome'=>'Monge','dado'=>'d8','atributo'=>'destreza','resistencias'=>['forca','destreza'],'pericias'=>['acrobacia','atletismo','historia','intuicao','religiao','furtividade'],'subclasses'=>['Elementos','Misericórdia','Mão Aberta','Sombra']],
  ['id'=>'paladino','nome'=>'Paladino','dado'=>'d10','atributo'=>'carisma','resistencias'=>['sabedoria','carisma'],'pericias'=>['atletismo','intuicao','intimidacao','medicina','persuasao','religiao'],'subclasses'=>['Devoção','Glória','Antigos','Vingança']],
  ['id'=>'patrulheiro','nome'=>'Patrulheiro','dado'=>'d10','atributo'=>'destreza','resistencias'=>['forca','destreza'],'pericias'=>['adestrar_animais','atletismo','intuicao','investigacao','natureza','percepcao','furtividade','sobrevivencia'],'subclasses'=>['Mestre das Feras','Andarilho Feérico','Perseguidor das Trevas','Caçador']],
  ['id'=>'ladino','nome'=>'Ladino','dado'=>'d8','atributo'=>'destreza','resistencias'=>['destreza','inteligencia'],'pericias'=>['acrobacia','atletismo','enganacao','intuicao','intimidacao','investigacao','percepcao','atuacao','persuasao','prestidigitacao','furtividade'],'subclasses'=>['Trapaceiro Arcano','Assassino','Lâmina Psíquica','Ladrão']],
  ['id'=>'feiticeiro','nome'=>'Feiticeiro','dado'=>'d6','atributo'=>'carisma','resistencias'=>['constituicao','carisma'],'pericias'=>['arcanismo','enganacao','intuicao','intimidacao','persuasao','religiao'],'subclasses'=>['Aberrante','Relógio','Dracônico','Magia Selvagem']],
  ['id'=>'bruxo','nome'=>'Bruxo','dado'=>'d8','atributo'=>'carisma','resistencias'=>['sabedoria','carisma'],'pericias'=>['arcanismo','enganacao','historia','intimidacao','investigacao','natureza','religiao'],'subclasses'=>['Arquifada','Celestial','Infernal','Grande Antigo']],
  ['id'=>'mago','nome'=>'Mago','dado'=>'d6','atributo'=>'inteligencia','resistencias'=>['inteligencia','sabedoria'],'pericias'=>['arcanismo','historia','intuicao','investigacao','medicina','religiao'],'subclasses'=>['Abjuração','Adivinhação','Evocação','Ilusão']]
 ],
 'especies'=>['Humano','Anão','Elfo','Halfling','Gnomo','Draconato','Orc','Tiefling','Aasimar','Goliath','Goblin'],
 'origens'=>['Acólito','Artesão','Artista','Charlatão','Criminoso','Fazendeiro','Guarda','Guia','Herói do Povo','Mercador','Nobre','Sábio','Marinheiro','Soldado','Eremita','Escriba'],
 'talentos'=>['Alerta','Atleta','Conjurador de Guerra','Curandeiro','Duro','Especialista em Perícia','Iniciado em Magia','Mestre em Armas','Sortudo','Móvel','Observador','Resiliente','Robusto','Resistente','Sentinela','Taverneiro','Telecinético','Telepático','Perito','Atirador'],
 'pericias'=>['acrobacia'=>'Acrobacia','adestrar_animais'=>'Adestrar Animais','arcanismo'=>'Arcanismo','atletismo'=>'Atletismo','enganacao'=>'Enganação','historia'=>'História','intuicao'=>'Intuição','intimidacao'=>'Intimidação','investigacao'=>'Investigação','medicina'=>'Medicina','natureza'=>'Natureza','percepcao'=>'Percepção','atuacao'=>'Atuação','persuasao'=>'Persuasão','religiao'=>'Religião','prestidigitacao'=>'Prestidigitação','furtividade'=>'Furtividade','sobrevivencia'=>'Sobrevivência'],
 'equipamentos'=>['Adaga','Arco Curto','Arco Longo','Espada Curta','Espada Longa','Espada Grande','Machado de Batalha','Machado Grande','Maça','Martelo de Guerra','Lança','Besta Leve','Besta Pesada','Escudo','Armadura de Couro','Armadura de Couro Batido','Cota de Malha','Peitoral','Cota de Talas','Poção de Cura','Mochila de Aventureiro','Mochila de Explorador','Corda de Cânhamo','Tocha','Pederneira','Rações','Cantil','Manto','Kit de Curandeiro','Ferramentas de Ladrão','Instrumento Musical'],
 'magias'=>['Acudir os Moribundos','Amizade Animal','Armadura Arcana','Armadura de Agathys','Bênção','Comando','Curar Ferimentos','Detectar Magia','Escudo','Fogo das Fadas','Mãos Flamejantes','Mísseis Mágicos','Palavra Curativa','Raio de Fogo','Sono','Thunderwave','Imagem Espelhada','Invisibilidade','Passo Nebuloso','Teia','Bola de Fogo','Contramágica','Dissipar Magia','Relâmpago','Voo','Porta Dimensional','Invisibilidade Maior','Muralha de Fogo','Teletransporte','Cura Completa'],
 'apendices'=>[
  'condicoes'=>['Amedrontado','Agarrado','Atordoado','Cego','Enfeitiçado','Envenenado','Impedido','Incapacitado','Inconsciente','Invisível','Paralisado','Petrificado','Surdo','Caído','Contido'],
  'sentidos'=>['Visão no Escuro','Visão no Escuro Superior','Visão Verdadeira','Percepção Passiva','Sentido Sísmico'],
  'idiomas'=>['Comum','Anão','Élfico','Gigante','Gnômico','Goblin','Halfling','Orc','Abissal','Celestial','Dracônico','Infernal','Primordial','Silvestre','Subcomum'],
  'danos'=>['Ácido','Concussão','Frio','Fogo','Força','Elétrico','Necrótico','Perfurante','Veneno','Psíquico','Radiante','Cortante','Trovejante'],
  'tamanhos'=>['Pequeno','Médio','Grande']
 ],

 'alinhamentos'=>[
  'Ordeiro e Bom (OB)','Ordeiro e Neutro (ON)','Ordeiro e Mau (OM)',
  'Neutro e Bom (NB)','Neutro (N)','Neutro e Mau (NM)',
  'Caótico e Bom (CB)','Caótico e Neutro (CN)','Caótico e Mau (CM)'
 ],
 'metodos_atributos'=>[
  'padrao'=>'Conjunto Padrão','pontos'=>'Compra de Pontos','rolagem'=>'Rolagem 4d6','manual'=>'Manual'
 ],
 'idiomas_especie'=>[
  'Humano'=>'Comum','Anão'=>'Anão','Elfo'=>'Élfico','Halfling'=>'Pequenino','Gnomo'=>'Gnômico',
  'Draconato'=>'Dracônico','Orc'=>'Orc','Tiefling'=>'Infernal','Aasimar'=>'Celestial','Goliath'=>'Gigante','Goblin'=>'Goblin'
 ],
 'detalhes_classes'=>[
  'bardo'=>[
   'nome'=>'Bardo','descricao'=>'Conjurador versátil que canaliza magia por meio da música, palavras, arte e dança.','pericias_escolha'=>3,
   'armaduras'=>'Leve','armas'=>'Simples','subclasse_nivel'=>3,
   'caracteristicas'=>[
    ['nome'=>'Inspiração de Bardo','texto'=>'Você pode inspirar outros sobrenaturalmente por meio de palavras, música ou dança. O dado de Inspiração de Bardo é um d6. Como Ação Bônus, você pode inspirar uma criatura a até 18 metros que possa vê-lo ou ouvi-lo. Após uma falha em um Teste de D20, a criatura pode jogar o dado e adicionar o resultado. Você recupera os usos ao completar um Descanso Longo. O dado se torna d8 no nível 5, d10 no nível 10 e d12 no nível 15.'],
    ['nome'=>'Conjuração','texto'=>'Você aprende truques e prepara magias da lista de Bardo. Carisma é seu atributo de conjuração e um Instrumento Musical pode ser usado como Foco de Conjuração.']
   ]
  ]
 ],
 'detalhes_especies'=>[
  'Aasimar'=>[
   'descricao'=>'Aasimar carregam uma centelha dos Planos Superiores dentro de suas almas, podendo manifestar poder celestial.', 'deslocamento'=>'9 metros',
   'tracos'=>[
    ['nome'=>'Resistência Celestial','texto'=>'Você tem resistência a dano Necrótico e Radiante.'],
    ['nome'=>'Visão no Escuro','texto'=>'Você tem Visão no Escuro com alcance de 18 metros.'],
    ['nome'=>'Mãos Curativas','texto'=>'Você pode tocar uma criatura e restaurar Pontos de Vida rolando um número de d4s igual ao seu Bônus de Proficiência. Recupera o uso após Descanso Longo.'],
    ['nome'=>'Portador da Luz','texto'=>'Você conhece o truque Luz. Carisma é seu atributo de conjuração para ele.'],
    ['nome'=>'Revelação Celestial','texto'=>'A partir do nível 3, você pode se transformar por 1 minuto, escolhendo Asas Celestiais, Manto Necrótico ou Transfiguração Radiante. Após usar, recupera o uso com um Descanso Longo.']
   ]
  ]
 ],
 'detalhes_origens'=>[
  'Sábio'=>[
   'descricao'=>'Você passou seus anos de formação viajando entre mansões e mosteiros, realizando trabalhos em troca de acesso a bibliotecas. Suas noites foram dedicadas ao estudo de livros e pergaminhos.',
   'pericias'=>['Arcanismo','História'],'ferramentas'=>'Suprimentos de Calígrafo','talento'=>'Iniciado em Magia (Mago)',
   'atributos'=>['Constituição','Inteligência','Sabedoria'],
   'equipamento'=>'Escolha A ou B: (A) Cajado, Suprimentos de Calígrafo, Livro (história), Pergaminho (8 folhas), Túnica, 8 PO; ou (B) 50 PO.'
  ]
 ],
 'regras'=>['modificador'=>'floor((atributo - 10) / 2)','proficiencia'=>'2 + floor((nivel - 1) / 4)','iniciativa'=>'modificador de Destreza','ca_base'=>'10 + modificador de Destreza','pv'=>'PV máximo e atual independentes; PV atual limitado a 0..PV máximo quando dano/cura são aplicados']
];
