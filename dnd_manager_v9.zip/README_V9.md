# D&D Manager V9

Evolução da V8 com foco em criação/edição orientada a regras.

## Novidades
- Idioma principal definido pela espécie e até 2 idiomas adicionais.
- Alinhamento fechado nos nove valores solicitados.
- Atributos por Conjunto Padrão, Compra de Pontos, Rolagem 4d6 descartando o menor e Manual.
- Bônus de proficiência e atributo primário apresentados conforme classe.
- Painéis de características para classe, espécie e origem; Bardo, Aasimar e Sábio possuem conteúdo detalhado de referência informado para esta versão.
- Dados Poker permitem escolher 0, 1 ou 2 dados para uma única rerrolagem. O servidor controla token e uso único.
- Histórico Poker é atualizado para o resultado final.
- JSON passa a usar schema_versao 9, preservando campos desconhecidos.

## Banco
Para banco existente, execute `database/migracao_v9.sql` depois das migrações anteriores.
Novas instalações podem usar `database/schema.sql`, que já contém as colunas do Poker V9.

## Conteúdo
O catálogo é estruturado e extensível. Para conteúdo integral de obras protegidas, use somente material autorizado/licenciado.
