USE dnd_campaign;

/* V4 - adiciona suporte ao dado Poker sem apagar dados existentes. */
SET @sql = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE rolagens ADD COLUMN tipo VARCHAR(20) NOT NULL DEFAULT ''numerico'' AFTER detalhes',
  'SELECT 1') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND column_name = 'tipo');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE rolagens ADD COLUMN resultado_visual LONGTEXT NULL AFTER tipo',
  'SELECT 1') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND column_name = 'resultado_visual');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(COUNT(*) = 0,
  'CREATE INDEX idx_rolagens_mesa_tipo ON rolagens(mesa_id, tipo, criado_em)',
  'SELECT 1') FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND index_name = 'idx_rolagens_mesa_tipo');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
