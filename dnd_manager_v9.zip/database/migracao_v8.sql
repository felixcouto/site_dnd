-- D&D Manager V8 - recuperação e alteração segura de senha
USE dnd_campaign;

CREATE TABLE IF NOT EXISTS recuperacao_senha (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 usuario_id INT NOT NULL,
 token_hash CHAR(64) NOT NULL UNIQUE,
 expira_em DATETIME NOT NULL,
 usado_em DATETIME NULL,
 criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

CREATE INDEX idx_recuperacao_usuario ON recuperacao_senha(usuario_id, usado_em, expira_em);

-- Marca o momento da última alteração de senha sem substituir a senha existente.
SET @col_exists := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='usuarios' AND column_name='senha_alterada_em');
SET @sql := IF(@col_exists=0,'ALTER TABLE usuarios ADD COLUMN senha_alterada_em DATETIME NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
