-- D&D Manager V5 - migração segura para banco existente
-- Não apaga personagens, mesas ou rolagens. A ficha V5 permanece compatível via JSON.
USE dnd_campaign;

CREATE TABLE IF NOT EXISTS personagem_historico (
 id BIGINT AUTO_INCREMENT PRIMARY KEY,
 personagem_id INT NOT NULL,
 usuario_id INT NULL,
 versao INT NOT NULL DEFAULT 5,
 snapshot LONGTEXT NOT NULL,
 criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(personagem_id) REFERENCES personagens(id) ON DELETE CASCADE,
 FOREIGN KEY(usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
);

CREATE INDEX IF NOT EXISTS idx_personagem_historico_personagem ON personagem_historico(personagem_id, id);

-- V5 não exige colunas novas na tabela personagens: dados LONGTEXT continua sendo a fonte completa da ficha.
-- A estrutura permite preservar campos antigos e novos sem perda durante importação/edição.
