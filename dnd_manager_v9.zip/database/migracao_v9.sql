USE dnd_campaign;

SET @c := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='rolagens' AND column_name='poker_rerrolado');
SET @sql := IF(@c=0,'ALTER TABLE rolagens ADD COLUMN poker_rerrolado TINYINT(1) NOT NULL DEFAULT 0','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='rolagens' AND column_name='poker_token_hash');
SET @sql := IF(@c=0,'ALTER TABLE rolagens ADD COLUMN poker_token_hash CHAR(64) NULL','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @i := (SELECT COUNT(*) FROM information_schema.statistics WHERE table_schema=DATABASE() AND table_name='rolagens' AND index_name='idx_rolagens_poker_token');
SET @sql := IF(@i=0,'CREATE INDEX idx_rolagens_poker_token ON rolagens(poker_token_hash)','SELECT 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
