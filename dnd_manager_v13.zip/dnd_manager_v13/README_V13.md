# D&D Manager V13

## Alterações
- Histórico dos dados Poker organizado em três colunas: **Inicial**, **Substituição** e **Final**.
- A coluna Inicial mantém todos os dados da primeira rolagem.
- A coluna Substituição mostra as faces antigas dos dados selecionados para rerrolagem.
- A coluna Final mostra todos os dados após a rerrolagem, substituindo somente os índices selecionados.
- A rolagem atual permanece visível com imagens dos dados Poker antes e depois da rerrolagem.
- O registro do histórico é atualizado na mesma linha, sem criar uma nova entrada para a rerrolagem.
- Os dados de substituição são persistidos no resultado visual para preservar o histórico.

Não é necessária migração do banco de dados em relação à V12.
