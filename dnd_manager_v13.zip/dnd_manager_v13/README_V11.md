# D&D Manager V11

## Correções no sistema Poker

- Corrigido o controle de estado da rerrolagem no JavaScript.
- A ação de rerrolar é identificada explicitamente pelo servidor, inclusive quando o usuário escolhe zero dados.
- Ao selecionar 1 ou 2 dados, somente as posições escolhidas são geradas novamente.
- A tela de resultado apresenta imediatamente a combinação atualizada.
- O histórico mantém a rolagem inicial e exibe, na mesma linha, a atualização com a face anterior → face nova.
- A rerrolagem continua limitada a uma única utilização por jogada, validada no servidor.
- O histórico persistido também mostra a comparação depois de recarregar a página.

## Instalação

A V11 é uma atualização da V10. Faça backup do projeto e do banco de dados e substitua os arquivos pelos desta versão. Não há alteração estrutural do banco de dados.

## Observação

O histórico preserva o resultado inicial e o resultado final na mesma entrada da rolagem. As rolagens antigas já existentes, feitas antes da V11, não terão dados de face inicial separados se a versão anterior já os sobrescreveu.
