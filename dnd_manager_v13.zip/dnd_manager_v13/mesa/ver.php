<?php
require '../config/layout.php';
exigeLogin();
$u=usuario();
$id=(int)($_GET['id']??0);
$s=$pdo->prepare('SELECT m.*,u.nome mestre FROM mesas m JOIN usuarios u ON u.id=m.mestre_id WHERE m.id=?');$s->execute([$id]);$m=$s->fetch();
if(!$m||($u['tipo']!=='admin'&&!temMesa($id,$u['id']))) die('Sem acesso.');
$s=$pdo->prepare('SELECT p.*,u.nome jogador FROM personagens p JOIN usuarios u ON u.id=p.usuario_id WHERE p.mesa_id=? ORDER BY p.nome');$s->execute([$id]);$ps=$s->fetchAll();
$ehMestre=$m['mestre_id']==$u['id']||$u['tipo']==='admin';
$s=$pdo->prepare('SELECT r.*,u.nome usuario,p.nome personagem FROM rolagens r JOIN usuarios u ON u.id=r.usuario_id LEFT JOIN personagens p ON p.id=r.personagem_id WHERE r.mesa_id=? ORDER BY r.id DESC LIMIT 60');$s->execute([$id]);$rolls=$s->fetchAll();
$member=$pdo->prepare('SELECT u.id,u.nome,mm.funcao FROM mesa_membros mm JOIN usuarios u ON u.id=mm.usuario_id WHERE mm.mesa_id=? ORDER BY u.nome');$member->execute([$id]);$members=$member->fetchAll();
top('Mesa · '.$m['nome']);
?>
<div class="card sheet-head">
<?php if($m['imagem']):?><img class="preview-square" src="<?=h($m['imagem'])?>"><?php endif;?>
<div class="sheet-title"><h1><?=h($m['nome'])?></h1><p><?=h($m['descricao'])?></p><div class="tabs"><span class="tag">Código <?=h($m['codigo'])?></span><span class="tag">Mestre: <?=h($m['mestre'])?></span><span class="tag"><?=count($members)?> jogadores</span><span class="tag"><?=count($ps)?> personagens</span></div></div>
<div class="sheet-actions"><?php if($ehMestre):?><a class="btn gold" href="editar.php?id=<?=$id?>">Editar mesa</a><?php endif;?><a class="btn" href="../export/mesa.php?id=<?=$id?>">JSON</a><a class="btn" target="_blank" href="../export/mesa_pdf.php?id=<?=$id?>">PDF</a></div>
</div>

<div class="grid-2 section">
<div class="card"><div class="section-title"><h2>Jogadores e personagens</h2><span></span></div>
<?php if(!$ps):?><div class="empty">Nenhum personagem está associado à mesa.</div>
<?php else:foreach($ps as $p):$d=json_decode($p['dados'],true)?:[];?><div class="member-card section"><div class="hero"><?php if($p['imagem']):?><img class="avatar" src="<?=h($p['imagem'])?>"><?php endif;?><div><b><?=h($p['nome'])?></b><div class="small"><?=h($d['classe']??'')?> · Nível <?=h($d['nivel']??1)?> · Jogador: <?=h($p['jogador'])?></div><div class="small">PV <?=h($d['pv_atual']??0)?> / <?=h($d['pv_max']??0)?> · CA <?=h($d['ca']??10)?></div></div></div><a class="btn smallbtn" href="../personagem/editar.php?id=<?=$p['id']?>">Abrir ficha</a></div><?php endforeach;endif;?></div>
<div class="card"><div class="section-title"><h2>Membros</h2><span></span></div><?php if(!$members):?><div class="empty">Nenhum membro adicional.</div><?php else:foreach($members as $mm):?><div class="member-card"><span><?=h($mm['nome'])?></span><span class="tag"><?=h($mm['funcao'])?></span></div><?php endforeach;endif;?></div>
</div>

<div class="grid-2 section">
<div class="card">
<div class="section-title"><h2>Rolagem de dados</h2><span></span></div>
<div class="roll-tabs"><button type="button" class="roll-tab active" id="tabNumeric" onclick="setRollMode('numerico')">🎲 Dados D&D</button><button type="button" class="roll-tab" id="tabPoker" onclick="setRollMode('poker')">🂱 Dados Poker</button></div>
<div id="numericMode">
<p class="small">Dados tradicionais: d4, d6, d8, d10, d12, d20 e d100.</p>
<div class="grid-2 section"><div><label>Quantidade de dados</label><input class="input" id="numericQty" type="number" min="1" max="20" value="1" oninput="syncExpression()"></div><div><label>Modificador</label><input class="input" id="numericMod" type="number" value="0" oninput="syncExpression()"></div></div><div class="roll-dice"><?php foreach([4,6,8,10,12,20,100] as $n):?><button type="button" class="btn" onclick="rollDie(<?=$n?>)">d<?=$n?></button><?php endforeach;?></div>
<div class="grid-2 section"><div><label>Expressão</label><input class="input" id="expr" value="1d20 + 0" placeholder="2d20 + 5"></div><div><label>Personagem</label><select class="input" id="char"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="roll(document.getElementById('expr').value)">🎲 Rolar</button>
</div>

<div id="pokerMode" class="hidden">
<p class="small">Dado Poker de 6 faces: <b>Ás, K, Q, J, 10 e 9</b>. As cores seguem o padrão visual solicitado.</p>
<div class="poker-face-reference">
<div class="poker-ref poker-black"><span>🂱</span><b>Ás</b><small>Preto</small></div>
<div class="poker-ref poker-red"><span>🃞</span><b>K</b><small>Vermelho</small></div>
<div class="poker-ref poker-green"><span>🃝</span><b>Q</b><small>Verde</small></div>
<div class="poker-ref poker-blue"><span>🂻</span><b>J</b><small>Azul</small></div>
<div class="poker-ref poker-purple"><span>🃊</span><b>10</b><small>Roxo/Rosa</small></div>
<div class="poker-ref poker-orange"><span>🃉</span><b>9</b><small>Laranja/Amarelo</small></div>
</div>
<div class="grid-2 section"><div><label>Quantidade de dados Poker</label><input class="input" id="pokerQty" type="number" min="1" max="20" value="5"></div><div><label>Personagem</label><select class="input" id="pokerChar"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="rollPoker()">🃏 Rolar Poker</button><div id="pokerRerollControls" class="section hidden"><div class="notice">Escolha <b>0 a 2 dados</b> e clique em “Rolar novamente”. Essa segunda rolagem só pode ser usada uma vez.</div><button type="button" class="btn" id="rerollPokerBtn" onclick="rerollPoker()">🔄 Rolar novamente (0/2)</button></div>
</div>
<div id="rollResult" class="roll-result section">—</div>
<div id="pokerResult" class="poker-result hidden"></div>
</div>

<div class="card"><div class="section-title"><h2>Histórico de rolagens</h2><span></span></div><div class="dice-history" id="history">
<?php foreach($rolls as $r): $rv=json_decode($r['resultado_visual']??'',true)?:[]; $isPoker=($r['tipo']??'numerico')==='poker'; ?>
<div class="history-row"><div><b><?=h($isPoker ? ($rv['combinacao']??'Poker') : $r['resultado'])?></b> · <?=h($r['expressao'])?><div class="small"><?=h($r['usuario'])?><?php if($r['personagem']):?> · <?=h($r['personagem'])?><?php endif;?></div><?php if($isPoker&&isset($rv['faces'])):$initial=$rv['faces_iniciais']??$rv['faces'];$current=$rv['faces'];$changed=$rv['dados_rerrolados']??[];$sub=$rv['faces_substituidas']??array_map(fn($i)=>$initial[$i]??null,$changed);?>
<div class="poker-history-flow">
 <div class="poker-history-stage"><b>Inicial</b><div class="history-poker-faces"><?php foreach($initial as $f):?><img class="mini-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado <?=h($f['codigo'])?>" title="<?=h($f['nome'])?>"><?php endforeach;?></div></div>
 <div class="poker-history-stage"><b>Substituição</b><div class="history-poker-faces"><?php if(!empty($rv['rerrolado'])):foreach($sub as $f):if($f):?><img class="mini-poker-img selected-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado selecionado <?=h($f['codigo'])?>" title="Selecionado: <?=h($f['nome'])?>"><?php endif;endforeach;else:?><span class="small">—</span><?php endif;?></div></div>
 <div class="poker-history-stage"><b>Final</b><div class="history-poker-faces"><?php foreach($current as $f):?><img class="mini-poker-img final-poker-img" src="<?=h('../public/images/poker/'.str_replace('poker-','',$f['classe']).'.svg')?>" alt="Dado final <?=h($f['codigo'])?>" title="Final: <?=h($f['nome'])?>"><?php endforeach;?></div></div>
</div><?php else: ?><div class="small"><?=h($r['detalhes'])?></div><?php endif;?></div><span class="small"><?=h($r['criado_em'])?></span></div>
<?php endforeach;if(!$rolls):?><div class="empty">Nenhuma rolagem ainda.</div><?php endif;?></div></div>
</div>

<script>
const mesaId='<?= $id ?>';
function setRollMode(mode){
 document.getElementById('numericMode').classList.toggle('hidden',mode!=='numerico');
 document.getElementById('pokerMode').classList.toggle('hidden',mode!=='poker');
 document.getElementById('tabNumeric').classList.toggle('active',mode==='numerico');
 document.getElementById('tabPoker').classList.toggle('active',mode==='poker');
 document.getElementById('rollResult').classList.toggle('hidden',mode==='poker');
 document.getElementById('pokerResult').classList.toggle('hidden',mode!=='poker');
}
function syncExpression(){const q=Math.max(1,Math.min(20,parseInt(document.getElementById('numericQty').value||1,10)));const mod=parseInt(document.getElementById('numericMod').value||0,10);const ex=document.getElementById('expr');const m=ex.value.match(/d(4|6|8|10|12|20|100)/i);if(m)ex.value=q+'d'+m[1]+(mod?(mod>0?' + ':' - ')+Math.abs(mod):'');}
function rollDie(sides){const q=Math.max(1,Math.min(20,parseInt(document.getElementById('numericQty').value||1,10)));const mod=parseInt(document.getElementById('numericMod').value||0,10);const expr=q+'d'+sides+(mod?(mod>0?' + ':' - ')+Math.abs(mod):'');document.getElementById('expr').value=expr;roll(expr);}
function pokerImagePath(face){const slug=(face?.classe||'poker-black').replace('poker-','');return '../public/images/poker/'+slug+'.svg';}
function pokerImg(face, cls='mini-poker-img'){
 const img=document.createElement('img');img.className=cls;img.src=pokerImagePath(face);img.alt='Dado '+(face?.codigo||'');img.title=face?.nome||face?.codigo||'';return img;
}
function historyStage(label, faces, extraClass=''){
 const stage=document.createElement('div');stage.className='poker-history-stage '+extraClass;
 const heading=document.createElement('b');heading.textContent=label;stage.appendChild(heading);
 const list=document.createElement('div');list.className='history-poker-faces';(faces||[]).forEach(f=>list.appendChild(pokerImg(f,'mini-poker-img '+extraClass)));stage.appendChild(list);return stage;
}
function renderHistoryFlow(container,j){
 const flow=document.createElement('div');flow.className='poker-history-flow';
 const initial=j.faces_iniciais||j.faces||[];const selected=(j.dados_rerrolados||[]).map(i=>(initial[i]));const final=j.faces||[];
 flow.appendChild(historyStage('Inicial',initial));
 const replacement=historyStage('Substituição',j.rerrolado?selected:[],'selected-poker-img');
 if(!j.rerrolado){const empty=document.createElement('span');empty.className='small';empty.textContent='—';replacement.querySelector('.history-poker-faces').appendChild(empty);}
 flow.appendChild(replacement);flow.appendChild(historyStage('Final',final,'final-poker-img'));container.appendChild(flow);
}
function addHistory(j, isPoker){
 const h=document.getElementById('history');const row=document.createElement('div');row.className='history-row';
 const left=document.createElement('div');const b=document.createElement('b');b.textContent=isPoker?(j.combinacao||'Poker'):j.resultado;left.appendChild(b);left.append(' · '+j.expressao);
 const small=document.createElement('div');small.className='small';small.textContent=(j.usuario||'')+(j.personagem?' · '+j.personagem:'');left.appendChild(small);
 if(isPoker)renderHistoryFlow(left,j);else{const d=document.createElement('div');d.className='small';d.textContent=j.detalhes||'';left.appendChild(d);}
 const time=document.createElement('span');time.className='small';time.textContent='agora';row.append(left,time);h.prepend(row);return row;
}
async function roll(expr){const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('expressao',expr);fd.append('personagem_id',document.getElementById('char').value);fd.append('modo','numerico');const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}document.getElementById('rollResult').textContent=j.resultado;addHistory(j,false);}
let pokerToken=null,pokerRerollUsed=false,pokerHistoryRow=null;
function updatePokerHistoryRow(row,j){
 const left=row.firstElementChild;left.innerHTML='';const b=document.createElement('b');b.textContent=j.combinacao||'Poker';left.appendChild(b);left.append(' · '+j.expressao);
 const small=document.createElement('div');small.className='small';small.textContent=(j.usuario||'')+(j.personagem?' · '+j.personagem:'');left.appendChild(small);renderHistoryFlow(left,j);
}
function renderPoker(j){
 const box=document.getElementById('pokerResult');box.innerHTML='';box.classList.remove('hidden');
 const title=document.createElement('div');title.className='poker-combo';title.textContent=j.combinacao||'Rolagem Poker';box.appendChild(title);
 const current=document.createElement('div');current.className='poker-current-label';current.textContent=j.rerrolado?'Resultado atual após substituição':'Rolagem atual';box.appendChild(current);
 const cards=document.createElement('div');cards.className='poker-roll';
 (j.faces||[]).forEach((f,i)=>{const c=document.createElement('button');c.type='button';c.className='poker-card '+f.classe;c.dataset.index=i;const img=document.createElement('img');img.className='poker-die-image';img.src=pokerImagePath(f);img.alt='Dado Poker '+f.codigo;c.appendChild(img);const name=document.createElement('small');name.textContent=f.nome;c.appendChild(name);if(!pokerRerollUsed&&!j.rerrolado)c.onclick=()=>togglePokerSelection(c);cards.appendChild(c);});box.appendChild(cards);
 const sum=document.createElement('div');sum.className='small poker-sum';sum.textContent='Valor interno da rolagem: '+j.resultado;box.appendChild(sum);
 if(j.rerrolado){const note=document.createElement('div');note.className='small';note.textContent='Rerrolagem concluída. A rolagem final está exibida acima.';box.appendChild(note);}
 document.getElementById('pokerRerollControls').classList.toggle('hidden',!!j.rerrolado||pokerRerollUsed);updateRerollCount();
}
function togglePokerSelection(card){if(pokerRerollUsed)return;const selected=document.querySelectorAll('.poker-card.reroll-selected');if(!card.classList.contains('reroll-selected')&&selected.length>=2){alert('Você pode selecionar no máximo 2 dados.');return;}card.classList.toggle('reroll-selected');updateRerollCount();}
function updateRerollCount(){const n=document.querySelectorAll('.poker-card.reroll-selected').length;const b=document.getElementById('rerollPokerBtn');if(b)b.textContent='🔄 Rolar novamente ('+n+'/2)';}
async function rollPoker(){
 pokerRerollUsed=false;pokerToken=null;pokerHistoryRow=null;
 const qty=Math.max(1,Math.min(20,parseInt(document.getElementById('pokerQty').value||5,10)));document.getElementById('pokerQty').value=qty;
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('quantidade',qty);fd.append('personagem_id',document.getElementById('pokerChar').value);
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 pokerToken=j.token;renderPoker(j);pokerHistoryRow=addHistory(j,true);
}
async function rerollPoker(){
 if(pokerRerollUsed||!pokerToken)return;const selected=[...document.querySelectorAll('.poker-card.reroll-selected')].map(x=>Number(x.dataset.index));
 if(selected.length>2){alert('Escolha no máximo 2 dados.');return;}
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('quantidade',document.getElementById('pokerQty').value);fd.append('personagem_id',document.getElementById('pokerChar').value);fd.append('poker_token',pokerToken);fd.append('reroll_action','1');selected.forEach(i=>fd.append('reroll_indices[]',i));
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 pokerRerollUsed=true;pokerToken=null;renderPoker(j);if(pokerHistoryRow){updatePokerHistoryRow(pokerHistoryRow,j);}else{pokerHistoryRow=addHistory(j,true);}document.getElementById('pokerRerollControls').classList.add('hidden');
}

</script>
<?php bottom(); ?>
