# Histórico de versão V12

A versão V12 introduziu imagens dos dados Poker na rolagem atual e no histórico. Para as melhorias mais recentes de rerrolagem e histórico em três etapas, consulte `README_V13.md`.
