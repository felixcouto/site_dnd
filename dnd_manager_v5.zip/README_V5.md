# D&D Manager V5

A V5 evolui a V4 com um sistema de Dados Poker com reroll controlado.

## Dados Poker

Cada dado possui seis faces sem numeração tradicional:
- Ás (A), símbolo 🂱, preto
- Rei (K), símbolo 🃞, vermelho
- Dama (Q), símbolo 🃝, verde
- Valete (J), símbolo 🂻, azul
- 10, símbolo 🃊, roxo/rosa
- 9, símbolo 🃙, laranja/amarelo

## Reroll

Depois da primeira rolagem Poker, o jogador pode selecionar de 0 a 2 dados e clicar em **Rolar novamente**. A operação só pode ser usada uma vez para aquela rolagem. O controle é validado no servidor, portanto desabilitar o botão no navegador não é a única proteção.

O resultado atualizado permanece na mesma rolagem do histórico, com os índices dos dados substituídos registrados no JSON visual. A interface destaca os dados selecionados e apresenta cada resultado com a cor correspondente à sua face.

## Menu

A navegação recebeu espaçamento adicional entre os links. O contexto do jogador também é visualmente separado, mantendo nome, tipo de usuário e demais elementos do menu legíveis.

## Banco de dados

Para bancos existentes, executar `database/migracao_v5_poker_reroll.sql` depois da migração V4. A migração é condicional e não recria nem apaga as tabelas existentes.

## Compatibilidade

Os dados tradicionais continuam funcionando. Os campos desconhecidos dos personagens continuam preservados no JSON, e o histórico de rolagens anterior permanece compatível.
