USE dnd_campaign;

/* V5 - controle de reroll único para rolagens Poker existentes. */
SET @sql = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE rolagens ADD COLUMN poker_reroll_usado TINYINT(1) NOT NULL DEFAULT 0 AFTER resultado_visual',
  'SELECT 1') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND column_name = 'poker_reroll_usado');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(COUNT(*) = 0,
  'ALTER TABLE rolagens ADD COLUMN poker_reroll_indices VARCHAR(40) NULL AFTER poker_reroll_usado',
  'SELECT 1') FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND column_name = 'poker_reroll_indices');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @sql = (SELECT IF(COUNT(*) = 0,
  'CREATE INDEX idx_rolagens_poker_reroll ON rolagens(mesa_id,tipo,poker_reroll_usado)',
  'SELECT 1') FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'rolagens' AND index_name = 'idx_rolagens_poker_reroll');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
