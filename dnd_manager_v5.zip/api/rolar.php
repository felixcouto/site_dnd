<?php
require '../config/auth.php';
header('Content-Type: application/json; charset=utf-8');

$POKER_FACES = [
    1 => ['valor'=>6, 'codigo'=>'A',  'nome'=>'Ás',    'simbolo'=>'🂱', 'cor'=>'preto',             'classe'=>'poker-black'],
    2 => ['valor'=>5, 'codigo'=>'K',  'nome'=>'Rei',    'simbolo'=>'🃔', 'cor'=>'vermelho',          'classe'=>'poker-red'],
    3 => ['valor'=>4, 'codigo'=>'Q',  'nome'=>'Dama',   'simbolo'=>'🃃', 'cor'=>'verde',             'classe'=>'poker-green'],
    4 => ['valor'=>3, 'codigo'=>'J',  'nome'=>'Valete', 'simbolo'=>'🂻', 'cor'=>'azul',              'classe'=>'poker-blue'],
    5 => ['valor'=>2, 'codigo'=>'10', 'nome'=>'10',     'simbolo'=>'🃊', 'cor'=>'roxo/rosa',         'classe'=>'poker-purple'],
    6 => ['valor'=>1, 'codigo'=>'9',  'nome'=>'9',      'simbolo'=>'🃙', 'cor'=>'laranja/amarelo',   'classe'=>'poker-orange'],
];

function pokerHand(array $faces): string {
    $counts = array_count_values(array_map(fn($f) => $f['codigo'], $faces));
    rsort($counts);
    if (!$counts) return 'Sem rolagem';
    if ($counts[0] === 5) return 'Quina';
    if ($counts[0] === 4) return 'Quadra';
    if ($counts[0] === 3 && (($counts[1] ?? 0) === 2)) return 'Full House';
    if ($counts[0] === 3) return 'Trinca';
    if ($counts[0] === 2 && (($counts[1] ?? 0) === 2)) return 'Dois pares';
    if ($counts[0] === 2) return 'Um par';
    return 'Carta alta';
}

function pokerTotal(array $faces): int {
    return array_sum(array_map(fn($f) => $f['valor'], $faces));
}

function pokerVisual(array $faces, string $hand, array $extra=[]): string {
    return json_encode(array_merge([
        'modo'=>'poker',
        'quantidade'=>count($faces),
        'faces'=>$faces,
        'combinacao'=>$hand,
        'reroll_usado'=>false,
        'reroll_indices'=>[],
    ], $extra), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
}

try {
    if (!isset($_SESSION['uid'])) throw new Exception('Faça login.');
    $u = usuario();
    $mesa = (int)($_POST['mesa_id'] ?? 0);
    $expr = trim($_POST['expressao'] ?? '');
    $pid = (int)($_POST['personagem_id'] ?? 0);
    $modo = strtolower(trim($_POST['modo'] ?? 'numerico'));
    $acao = strtolower(trim($_POST['acao'] ?? 'rolar'));

    if (!$mesa) throw new Exception('Mesa inválida.');
    if (!temMesa($mesa, $u['id']) && $u['tipo'] !== 'admin') throw new Exception('Sem acesso à mesa.');

    $person = null;
    if ($pid) {
        $s = $pdo->prepare('SELECT id,nome FROM personagens WHERE id=? AND mesa_id=?');
        $s->execute([$pid, $mesa]);
        $person = $s->fetch();
        if (!$person) throw new Exception('Personagem inválido.');
    }

    if ($modo === 'poker' && $acao === 'reroll') {
        $rollId = (int)($_POST['rolagem_id'] ?? 0);
        $indicesRaw = trim($_POST['indices'] ?? '');
        $indices = $indicesRaw === '' ? [] : array_values(array_unique(array_map('intval', explode(',', $indicesRaw))));
        if (count($indices) > 2) throw new Exception('Você pode escolher no máximo 2 dados para o reroll.');
        foreach ($indices as $idx) if ($idx < 0 || $idx > 19) throw new Exception('Dado selecionado inválido.');

        $s = $pdo->prepare('SELECT * FROM rolagens WHERE id=? AND mesa_id=? AND tipo="poker"');
        $s->execute([$rollId, $mesa]);
        $roll = $s->fetch();
        if (!$roll) throw new Exception('Rolagem Poker não encontrada.');
        if ((int)$roll['usuario_id'] !== (int)$u['id'] && $u['tipo'] !== 'admin') throw new Exception('Apenas o autor da rolagem pode usar o reroll.');

        $visual = json_decode($roll['resultado_visual'] ?? '', true);
        if (!is_array($visual) || empty($visual['faces'])) throw new Exception('Dados da rolagem Poker inválidos.');
        if (!empty($visual['reroll_usado'])) throw new Exception('O reroll desta rolagem já foi utilizado.');

        $faces = $visual['faces'];
        foreach ($indices as $idx) {
            if (!isset($faces[$idx])) throw new Exception('Um dos dados selecionados não existe.');
            $faces[$idx] = $POKER_FACES[random_int(1, 6)];
        }
        $hand = count($faces) === 5 ? pokerHand($faces) : 'Rolagem Poker';
        $visual['faces'] = $faces;
        $visual['combinacao'] = $hand;
        $visual['reroll_usado'] = true;
        $visual['reroll_indices'] = $indices;
        $visual['reroll_quantidade'] = count($indices);
        $visual['reroll_data'] = date('Y-m-d H:i:s');
        $total = pokerTotal($faces);
        $det = implode(' · ', array_map(fn($f) => $f['simbolo'].' '.$f['nome'], $faces)).' | '.$hand;
        $s = $pdo->prepare('UPDATE rolagens SET resultado=?,detalhes=?,resultado_visual=? WHERE id=?');
        $s->execute([$total,$det,json_encode($visual,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$rollId]);

        echo json_encode([
            'ok'=>true,'modo'=>'poker','acao'=>'reroll','rolagem_id'=>$rollId,'resultado'=>$total,
            'expressao'=>$roll['expressao'],'detalhes'=>$det,'usuario'=>$u['nome'],
            'personagem'=>$person['nome'] ?? '', 'faces'=>$faces,'combinacao'=>$hand,
            'reroll_usado'=>true,'reroll_indices'=>$indices,'reroll_quantidade'=>count($indices)
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($modo === 'poker') {
        $qtd = (int)($_POST['quantidade'] ?? 5);
        if ($qtd < 1 || $qtd > 20) throw new Exception('Use entre 1 e 20 dados Poker.');
        $faces = [];
        foreach (range(1, $qtd) as $_) $faces[] = $POKER_FACES[random_int(1, 6)];
        $hand = $qtd === 5 ? pokerHand($faces) : 'Rolagem Poker';
        $visual = pokerVisual($faces, $hand);
        $det = implode(' · ', array_map(fn($f) => $f['simbolo'].' '.$f['nome'], $faces)).' | '.$hand;
        $total = pokerTotal($faces);
        $expressao = 'POKER x'.$qtd;
        $s = $pdo->prepare('INSERT INTO rolagens(mesa_id,personagem_id,usuario_id,expressao,resultado,detalhes,tipo,resultado_visual) VALUES(?,?,?,?,?,?,?,?)');
        $s->execute([$mesa,$person['id']??null,$u['id'],$expressao,$total,$det,'poker',$visual]);
        $rollId = (int)$pdo->lastInsertId();
        echo json_encode([
            'ok'=>true,'modo'=>'poker','acao'=>'rolar','rolagem_id'=>$rollId,'resultado'=>$total,
            'expressao'=>$expressao,'detalhes'=>$det,'usuario'=>$u['nome'],'personagem'=>$person['nome']??'',
            'faces'=>$faces,'combinacao'=>$hand,'reroll_usado'=>false,'reroll_max'=>2
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    if (!preg_match('/^(\d{1,2})d(4|6|8|10|12|20|100)(?:\s*([+-])\s*(\d{1,3}))?$/i',$expr,$m)) throw new Exception('Use uma expressão como 1d20 + 4 ou 2d6.');
    if ((int)$m[1] < 1 || (int)$m[1] > 20) throw new Exception('Máximo de 20 dados por rolagem.');
    $qtd = (int)$m[1]; $faces = (int)$m[2];
    $mod = isset($m[4]) ? ((int)$m[4] * ($m[3] === '-' ? -1 : 1)) : 0;
    $total = $mod; $parts = [];
    for ($i=0; $i<$qtd; $i++) { $v=random_int(1,$faces); $parts[]=$v; $total += $v; }
    $det = implode(' + ',$parts).($mod?($mod>0?' + '.$mod:' - '.abs($mod)):'' );
    $visual = json_encode(['modo'=>'numerico','faces'=>$parts,'modificador'=>$mod], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
    $s = $pdo->prepare('INSERT INTO rolagens(mesa_id,personagem_id,usuario_id,expressao,resultado,detalhes,tipo,resultado_visual) VALUES(?,?,?,?,?,?,?,?)');
    $s->execute([$mesa,$person['id']??null,$u['id'],$expr,$total,$det,'numerico',$visual]);
    echo json_encode(['ok'=>true,'modo'=>'numerico','resultado'=>$total,'expressao'=>$expr,'detalhes'=>$det,'usuario'=>$u['nome'],'personagem'=>$person['nome']??''], JSON_UNESCAPED_UNICODE);
} catch(Throwable $e) {
    http_response_code(400); echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
