<?php
$host='localhost';$db='dnd_campaign';$user='root';$pass='';
try{$pdo=new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",$user,$pass,[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);}catch(Exception $e){die('Erro de conexão: '.htmlspecialchars($e->getMessage()));}
if(session_status()===PHP_SESSION_NONE)session_start();
function usuario(){global $pdo;if(empty($_SESSION['uid']))return null;static $u=null;if($u===null){$s=$pdo->prepare('SELECT * FROM usuarios WHERE id=?');$s->execute([$_SESSION['uid']]);$u=$s->fetch();}return $u;}
function exigeLogin(){if(!usuario()){header('Location: index.php');exit;}}
function exigePapel($p){$u=usuario();if(!$u||!in_array($u['tipo'],(array)$p,true)){http_response_code(403);exit('Acesso negado.');}}
function h($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function jsonDownload($name,$data){header('Content-Type: application/json; charset=utf-8');header('Content-Disposition: attachment; filename="'.basename($name).'"');echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT);exit;}
?>
