<?php
require '../config/layout.php';
exigeLogin();
$u=usuario();
$id=(int)($_GET['id']??0);
$s=$pdo->prepare('SELECT m.*,u.nome mestre FROM mesas m JOIN usuarios u ON u.id=m.mestre_id WHERE m.id=?');$s->execute([$id]);$m=$s->fetch();
if(!$m||($u['tipo']!=='admin'&&!temMesa($id,$u['id']))) die('Sem acesso.');
$s=$pdo->prepare('SELECT p.*,u.nome jogador FROM personagens p JOIN usuarios u ON u.id=p.usuario_id WHERE p.mesa_id=? ORDER BY p.nome');$s->execute([$id]);$ps=$s->fetchAll();
$ehMestre=$m['mestre_id']==$u['id']||$u['tipo']==='admin';
$s=$pdo->prepare('SELECT r.*,u.nome usuario,p.nome personagem FROM rolagens r JOIN usuarios u ON u.id=r.usuario_id LEFT JOIN personagens p ON p.id=r.personagem_id WHERE r.mesa_id=? ORDER BY r.id DESC LIMIT 60');$s->execute([$id]);$rolls=$s->fetchAll();
$member=$pdo->prepare('SELECT u.id,u.nome,mm.funcao FROM mesa_membros mm JOIN usuarios u ON u.id=mm.usuario_id WHERE mm.mesa_id=? ORDER BY u.nome');$member->execute([$id]);$members=$member->fetchAll();
top('Mesa · '.$m['nome']);
?>
<div class="card sheet-head">
<?php if($m['imagem']):?><img class="preview-square" src="<?=h($m['imagem'])?>"><?php endif;?>
<div class="sheet-title"><h1><?=h($m['nome'])?></h1><p><?=h($m['descricao'])?></p><div class="tabs"><span class="tag">Código <?=h($m['codigo'])?></span><span class="tag">Mestre: <?=h($m['mestre'])?></span><span class="tag"><?=count($members)?> jogadores</span><span class="tag"><?=count($ps)?> personagens</span></div></div>
<div class="sheet-actions"><?php if($ehMestre):?><a class="btn gold" href="editar.php?id=<?=$id?>">Editar mesa</a><?php endif;?><a class="btn" href="../export/mesa.php?id=<?=$id?>">JSON</a><a class="btn" target="_blank" href="../export/mesa_pdf.php?id=<?=$id?>">PDF</a></div>
</div>

<div class="grid-2 section">
<div class="card"><div class="section-title"><h2>Jogadores e personagens</h2><span></span></div>
<?php if(!$ps):?><div class="empty">Nenhum personagem está associado à mesa.</div>
<?php else:foreach($ps as $p):$d=json_decode($p['dados'],true)?:[];?><div class="member-card section"><div class="hero"><?php if($p['imagem']):?><img class="avatar" src="<?=h($p['imagem'])?>"><?php endif;?><div><b><?=h($p['nome'])?></b><div class="small"><?=h($d['classe']??'')?> · Nível <?=h($d['nivel']??1)?> · Jogador: <?=h($p['jogador'])?></div><div class="small">PV <?=h($d['pv_atual']??0)?> / <?=h($d['pv_max']??0)?> · CA <?=h($d['ca']??10)?></div></div></div><a class="btn smallbtn" href="../personagem/editar.php?id=<?=$p['id']?>">Abrir ficha</a></div><?php endforeach;endif;?></div>
<div class="card"><div class="section-title"><h2>Membros</h2><span></span></div><?php if(!$members):?><div class="empty">Nenhum membro adicional.</div><?php else:foreach($members as $mm):?><div class="member-card"><span><?=h($mm['nome'])?></span><span class="tag"><?=h($mm['funcao'])?></span></div><?php endforeach;endif;?></div>
</div>

<div class="grid-2 section">
<div class="card">
<div class="section-title"><h2>Rolagem de dados</h2><span></span></div>
<div class="roll-tabs"><button type="button" class="roll-tab active" id="tabNumeric" onclick="setRollMode('numerico')">🎲 Dados D&D</button><button type="button" class="roll-tab" id="tabPoker" onclick="setRollMode('poker')">🂱 Dados Poker</button></div>
<div id="numericMode">
<p class="small">Dados tradicionais: d4, d6, d8, d10, d12, d20 e d100.</p>
<div class="roll-dice"><?php foreach([4,6,8,10,12,20,100] as $n):?><button type="button" class="btn" onclick="roll('1d<?=$n?>')">d<?=$n?></button><?php endforeach;?></div>
<div class="grid-2 section"><div><label>Expressão</label><input class="input" id="expr" value="1d20 + 0" placeholder="2d20 + 5"></div><div><label>Personagem</label><select class="input" id="char"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="roll(document.getElementById('expr').value)">🎲 Rolar</button>
</div>

<div id="pokerMode" class="hidden">
<p class="small">Dado Poker de 6 faces: <b>Ás, K, Q, J, 10 e 9</b>. As cores seguem o padrão visual solicitado.</p>
<div class="poker-face-reference">
<div class="poker-ref poker-black"><span>🂱</span><b>Ás</b><small>Preto</small></div>
<div class="poker-ref poker-red"><span>🃔</span><b>K</b><small>Vermelho</small></div>
<div class="poker-ref poker-green"><span>🃃</span><b>Q</b><small>Verde</small></div>
<div class="poker-ref poker-blue"><span>🂻</span><b>J</b><small>Azul</small></div>
<div class="poker-ref poker-purple"><span>🃊</span><b>10</b><small>Roxo/Rosa</small></div>
<div class="poker-ref poker-orange"><span>🃉</span><b>9</b><small>Laranja/Amarelo</small></div>
</div>
<div class="grid-2 section"><div><label>Quantidade de dados Poker</label><input class="input" id="pokerQty" type="number" min="1" max="20" value="5"></div><div><label>Personagem</label><select class="input" id="pokerChar"><option value="">Sem personagem</option><?php foreach($ps as $p):?><option value="<?=$p['id']?>"><?=h($p['nome'])?></option><?php endforeach;?></select></div></div>
<button type="button" class="btn gold" onclick="rollPoker()">🃏 Rolar Poker</button>
</div>
<div id="rollResult" class="roll-result section">—</div>
<div id="pokerResult" class="poker-result hidden"></div>
</div>

<div class="card"><div class="section-title"><h2>Histórico de rolagens</h2><span></span></div><div class="dice-history" id="history">
<?php foreach($rolls as $r): $rv=json_decode($r['resultado_visual']??'',true)?:[]; $isPoker=($r['tipo']??'numerico')==='poker'; ?>
<div class="history-row"><div><b><?=h($isPoker ? ($rv['combinacao']??'Poker') : $r['resultado'])?></b> · <?=h($r['expressao'])?><div class="small"><?=h($r['usuario'])?><?php if($r['personagem']):?> · <?=h($r['personagem'])?><?php endif;?></div><?php if($isPoker&&isset($rv['faces'])):?><div class="history-poker-faces"><?php foreach($rv['faces'] as $f):?><span class="mini-poker <?=h($f['classe'])?>"><?=h($f['codigo'])?></span><?php endforeach;?></div><?php else: ?><div class="small"><?=h($r['detalhes'])?></div><?php endif;?></div><span class="small"><?=h($r['criado_em'])?></span></div>
<?php endforeach;if(!$rolls):?><div class="empty">Nenhuma rolagem ainda.</div><?php endif;?></div></div>
</div>

<script>
const mesaId='<?= $id ?>';
let pokerRollId=null;
let pokerFaces=[];
let pokerRerollUsed=false;
function setRollMode(mode){
 document.getElementById('numericMode').classList.toggle('hidden',mode!=='numerico');
 document.getElementById('pokerMode').classList.toggle('hidden',mode!=='poker');
 document.getElementById('tabNumeric').classList.toggle('active',mode==='numerico');
 document.getElementById('tabPoker').classList.toggle('active',mode==='poker');
 document.getElementById('rollResult').classList.toggle('hidden',mode==='poker');
 document.getElementById('pokerResult').classList.toggle('hidden',mode!=='poker');
}
function addHistory(j, isPoker){
 const h=document.getElementById('history');
 const row=document.createElement('div'); row.className='history-row';
 const left=document.createElement('div'); const b=document.createElement('b'); b.textContent=isPoker?(j.combinacao||'Poker'):j.resultado; left.appendChild(b); left.append(' · '+j.expressao);
 const small=document.createElement('div'); small.className='small'; small.textContent=j.usuario+(j.personagem?' · '+j.personagem:''); left.appendChild(small);
 if(isPoker){const fs=document.createElement('div');fs.className='history-poker-faces';(j.faces||[]).forEach(f=>{const s=document.createElement('span');s.className='mini-poker '+f.classe;s.textContent=f.codigo;fs.appendChild(s);});left.appendChild(fs);}else{const d=document.createElement('div');d.className='small';d.textContent=j.detalhes||'';left.appendChild(d);}
 const time=document.createElement('span');time.className='small';time.textContent='agora';row.append(left,time);h.prepend(row);
}
async function roll(expr){
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('expressao',expr);fd.append('personagem_id',document.getElementById('char').value);fd.append('modo','numerico');
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 document.getElementById('rollResult').textContent=j.resultado; addHistory(j,false);
}
function renderPokerResult(j){
 pokerRollId=j.rolagem_id||pokerRollId; pokerFaces=j.faces||[]; pokerRerollUsed=!!j.reroll_usado;
 const box=document.getElementById('pokerResult');box.innerHTML='';
 const meta=document.createElement('div');meta.className='poker-meta';
 meta.innerHTML='<span><b>Jogador:</b> '+escapeHtml(j.usuario||'')+'</span><span><b>Personagem:</b> '+escapeHtml(j.personagem||'Sem personagem')+'</span>';
 box.appendChild(meta);
 const title=document.createElement('div');title.className='poker-combo';title.textContent=j.combinacao||'Rolagem Poker';box.appendChild(title);
 const cards=document.createElement('div');cards.className='poker-roll';
 pokerFaces.forEach((f,i)=>{
   const c=document.createElement('button');c.type='button';c.className='poker-card '+f.classe+(pokerRerollUsed?' locked':'');c.dataset.index=i;
   c.innerHTML='<span class="poker-symbol">'+escapeHtml(f.simbolo)+'</span><strong>'+escapeHtml(f.codigo)+'</strong><small>'+escapeHtml(f.nome)+'</small>';
   if(!pokerRerollUsed){c.title='Selecionar este dado para reroll';c.onclick=()=>togglePokerDie(c,i);} else c.disabled=true;
   cards.appendChild(c);
 }); box.appendChild(cards);
 const sum=document.createElement('div');sum.className='small poker-sum';sum.textContent='Valor interno da rolagem: '+j.resultado;box.appendChild(sum);
 const action=document.createElement('div');action.className='poker-reroll-panel';
 if(pokerRerollUsed){action.innerHTML='<span class="reroll-done">✓ Reroll já utilizado nesta rolagem.</span>';} else {
   action.innerHTML='<div><b>Reroll:</b> selecione de 0 a 2 dados e use uma única vez.</div><div class="reroll-actions"><span id="rerollCount" class="tag">0/2 selecionados</span><button type="button" class="btn gold" onclick="rerollPoker()">🔄 Rolar novamente</button></div>';
 }
 box.appendChild(action);
}
function escapeHtml(v){return String(v).replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));}
function togglePokerDie(card,index){
 if(pokerRerollUsed)return;
 const selected=document.querySelectorAll('.poker-card.selected').length;
 if(card.classList.contains('selected')){card.classList.remove('selected');}
 else {if(selected>=2){alert('Você pode selecionar no máximo 2 dados.');return;} card.classList.add('selected');}
 const n=document.querySelectorAll('.poker-card.selected').length; const c=document.getElementById('rerollCount'); if(c)c.textContent=n+'/2 selecionados';
}
async function rerollPoker(){
 if(!pokerRollId||pokerRerollUsed){alert('Esta rolagem não possui reroll disponível.');return;}
 const selected=[...document.querySelectorAll('.poker-card.selected')].map(x=>x.dataset.index);
 if(selected.length>2){alert('Selecione no máximo 2 dados.');return;}
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('acao','reroll');fd.append('rolagem_id',pokerRollId);fd.append('indices',selected.join(','));
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 renderPokerResult(j);
 location.reload();
}
async function rollPoker(){
 const qty=Math.max(1,Math.min(20,parseInt(document.getElementById('pokerQty').value||5,10)));
 document.getElementById('pokerQty').value=qty;
 const fd=new FormData();fd.append('mesa_id',mesaId);fd.append('modo','poker');fd.append('quantidade',qty);fd.append('personagem_id',document.getElementById('pokerChar').value);
 const r=await fetch('../api/rolar.php',{method:'POST',body:fd});const j=await r.json();if(!j.ok){alert(j.error);return;}
 renderPokerResult(j); addHistory(j,true);
}
</script>
<?php bottom(); ?>
