<?php
require '../config/auth.php';
header('Content-Type: application/json; charset=utf-8');

$POKER_FACES = [
    1 => ['valor'=>6, 'codigo'=>'A',  'nome'=>'Ás',    'simbolo'=>'🂱', 'cor'=>'preto',  'classe'=>'poker-black'],
    2 => ['valor'=>5, 'codigo'=>'K',  'nome'=>'Rei',    'simbolo'=>'🃞', 'cor'=>'vermelho','classe'=>'poker-red'],
    3 => ['valor'=>4, 'codigo'=>'Q',  'nome'=>'Dama',   'simbolo'=>'🃝', 'cor'=>'verde',   'classe'=>'poker-green'],
    4 => ['valor'=>3, 'codigo'=>'J',  'nome'=>'Valete', 'simbolo'=>'🂻', 'cor'=>'azul',    'classe'=>'poker-blue'],
    5 => ['valor'=>2, 'codigo'=>'10', 'nome'=>'10',     'simbolo'=>'🃊', 'cor'=>'roxo/rosa','classe'=>'poker-purple'],
    6 => ['valor'=>1, 'codigo'=>'9',  'nome'=>'9',      'simbolo'=>'🃉', 'cor'=>'laranja/amarelo','classe'=>'poker-orange'],
];

function pokerHand(array $faces): string {
    $counts = array_count_values(array_map(fn($f) => $f['codigo'], $faces));
    rsort($counts);
    if (!$counts) return 'Sem rolagem';
    if ($counts[0] === 5) return 'Quina';
    if ($counts[0] === 4) return 'Quadra';
    if ($counts[0] === 3 && (($counts[1] ?? 0) === 2)) return 'Full House';
    if ($counts[0] === 3) return 'Trinca';
    if ($counts[0] === 2 && (($counts[1] ?? 0) === 2)) return 'Dois pares';
    if ($counts[0] === 2) return 'Um par';
    return 'Carta alta';
}

try {
    if (!isset($_SESSION['uid'])) throw new Exception('Faça login.');
    $u = usuario();
    $mesa = (int)($_POST['mesa_id'] ?? 0);
    $expr = trim($_POST['expressao'] ?? '');
    $pid = (int)($_POST['personagem_id'] ?? 0);
    $modo = strtolower(trim($_POST['modo'] ?? 'numerico'));

    if (!$mesa) throw new Exception('Mesa inválida.');
    if (!temMesa($mesa, $u['id']) && $u['tipo'] !== 'admin') throw new Exception('Sem acesso à mesa.');

    $person = null;
    if ($pid) {
        $s = $pdo->prepare('SELECT id,nome FROM personagens WHERE id=? AND mesa_id=?');
        $s->execute([$pid, $mesa]);
        $person = $s->fetch();
        if (!$person) throw new Exception('Personagem inválido.');
    }

    if ($modo === 'poker') {
        $qtd = (int)($_POST['quantidade'] ?? 5);
        if ($qtd < 1 || $qtd > 20) throw new Exception('Use entre 1 e 20 dados Poker.');

        $token = trim($_POST['poker_token'] ?? '');
        $reroll = isset($_POST['reroll_action']) && $_POST['reroll_action'] === '1';
        if ($reroll) {
            if ($token === '') throw new Exception('Token de rolagem Poker inválido.');
            $indices = array_values(array_unique(array_map('intval', (array)($_POST['reroll_indices'] ?? []))));
            if (count($indices) > 2) throw new Exception('Você pode escolher no máximo 2 dados para rerrolar.');
            $hash = hash('sha256',$token);
            $s = $pdo->prepare('SELECT * FROM rolagens WHERE poker_token_hash=? AND mesa_id=? AND usuario_id=? AND tipo="poker" LIMIT 1');
            $s->execute([$hash,$mesa,$u['id']]); $row=$s->fetch();
            if (!$row) throw new Exception('Rolagem Poker não encontrada.');
            if (!empty($row['poker_rerrolado'])) throw new Exception('Esta rolagem Poker já utilizou o rerrolamento.');
            $rv=json_decode($row['resultado_visual']??'',true)?:[]; $oldFaces=$rv['faces']??[]; $initialFaces=$rv['faces_iniciais']??$oldFaces;
            if (count($oldFaces)!==$qtd) { $qtd=count($oldFaces); }
            foreach($indices as $idx){ if($idx<0||$idx>=$qtd) throw new Exception('Índice de dado inválido.'); $oldFaces[$idx]=$POKER_FACES[random_int(1,6)]; }
            $hand=$qtd===5?pokerHand($oldFaces):'Rolagem Poker';
            $visual=json_encode(['modo'=>'poker','quantidade'=>$qtd,'faces_iniciais'=>array_map(fn($f)=>['codigo'=>$f['codigo'],'nome'=>$f['nome'],'simbolo'=>$f['simbolo'],'cor'=>$f['cor'],'classe'=>$f['classe']],$initialFaces),'faces'=>array_map(fn($f)=>['codigo'=>$f['codigo'],'nome'=>$f['nome'],'simbolo'=>$f['simbolo'],'cor'=>$f['cor'],'classe'=>$f['classe']],$oldFaces),'combinacao'=>$hand,'rerrolado'=>true,'dados_rerrolados'=>$indices],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
            $det=implode(' · ',array_map(fn($f)=>$f['simbolo'].' '.$f['nome'],$oldFaces)).' | '.$hand.' | rerrolados: '.implode(', ',array_map(fn($i)=>$i+1,$indices));
            $total=array_sum(array_map(fn($f)=>$f['valor'],$oldFaces));
            $s=$pdo->prepare('UPDATE rolagens SET resultado=?,detalhes=?,resultado_visual=?,poker_rerrolado=1 WHERE id=?');$s->execute([$total,$det,$visual,$row['id']]);
            echo json_encode(['ok'=>true,'modo'=>'poker','resultado'=>$total,'expressao'=>$row['expressao'],'detalhes'=>$det,'usuario'=>$u['nome'],'personagem'=>$person['nome']??'','faces'=>$oldFaces,'faces_iniciais'=>$initialFaces,'combinacao'=>$hand,'rerrolado'=>true,'dados_rerrolados'=>$indices,'token'=>null],JSON_UNESCAPED_UNICODE); exit;
        }

        $faces=[]; foreach(range(1,$qtd) as $_){$faces[]=$POKER_FACES[random_int(1,6)];}
        $hand=$qtd===5?pokerHand($faces):'Rolagem Poker';
        $visual=json_encode(['modo'=>'poker','quantidade'=>$qtd,'faces'=>array_map(fn($f)=>['codigo'=>$f['codigo'],'nome'=>$f['nome'],'simbolo'=>$f['simbolo'],'cor'=>$f['cor'],'classe'=>$f['classe']],$faces),'combinacao'=>$hand],JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $det=implode(' · ',array_map(fn($f)=>$f['simbolo'].' '.$f['nome'],$faces)).' | '.$hand;
        $total=array_sum(array_map(fn($f)=>$f['valor'],$faces)); $expressao='POKER x'.$qtd;
        $rawToken=bin2hex(random_bytes(32));$tokenHash=hash('sha256',$rawToken);
        $s=$pdo->prepare('INSERT INTO rolagens(mesa_id,personagem_id,usuario_id,expressao,resultado,detalhes,tipo,resultado_visual,poker_rerrolado,poker_token_hash) VALUES(?,?,?,?,?,?,?,?,0,?)');
        $s->execute([$mesa,$person['id']??null,$u['id'],$expressao,$total,$det,'poker',$visual,$tokenHash]);
        echo json_encode(['ok'=>true,'modo'=>'poker','resultado'=>$total,'expressao'=>$expressao,'detalhes'=>$det,'usuario'=>$u['nome'],'personagem'=>$person['nome']??'','faces'=>$faces,'faces_iniciais'=>$faces,'combinacao'=>$hand,'rerrolado'=>false,'token'=>$rawToken],JSON_UNESCAPED_UNICODE); exit;
    }

    if (!preg_match('/^(\d{1,2})d(4|6|8|10|12|20|100)(?:\s*([+-])\s*(\d{1,3}))?$/i',$expr,$m)) {
        throw new Exception('Use uma expressão como 1d20 + 4 ou 2d6.');
    }
    if ((int)$m[1] < 1 || (int)$m[1] > 20) throw new Exception('Máximo de 20 dados por rolagem.');
    $qtd = (int)$m[1];
    $faces = (int)$m[2];
    $mod = isset($m[4]) ? ((int)$m[4] * ($m[3] === '-' ? -1 : 1)) : 0;
    $total = $mod;
    $parts = [];
    for ($i=0; $i<$qtd; $i++) { $v=random_int(1,$faces); $parts[]=$v; $total += $v; }
    $det = implode(' + ',$parts).($mod?($mod>0?' + '.$mod:' - '.abs($mod)):'' );
    $visual = json_encode(['modo'=>'numerico','faces'=>$parts,'modificador'=>$mod], JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

    $s = $pdo->prepare('INSERT INTO rolagens(mesa_id,personagem_id,usuario_id,expressao,resultado,detalhes,tipo,resultado_visual) VALUES(?,?,?,?,?,?,?,?)');
    $s->execute([$mesa,$person['id']??null,$u['id'],$expr,$total,$det,'numerico',$visual]);
    echo json_encode(['ok'=>true,'modo'=>'numerico','resultado'=>$total,'expressao'=>$expr,'detalhes'=>$det,'usuario'=>$u['nome'],'personagem'=>$person['nome']??''], JSON_UNESCAPED_UNICODE);
} catch(Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
}
