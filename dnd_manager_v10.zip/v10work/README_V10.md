# D&D Manager V10

Evolução da V9 com ajustes de rolagem numérica e criação de personagem.

## Novidades
- Quantidade de dados numéricos configurável de 1 a 20, com atalhos d4, d6, d8, d10, d12, d20 e d100.
- Campo de modificador e expressão editável no formato NdX +/- modificador. A API valida quantidade máxima de 20 dados.
- Botão para aplicar distribuição sugerida conforme atributo primário da classe selecionada. Usa o conjunto 15, 14, 13, 12, 10 e 8, priorizando o atributo principal e atributos secundários adequados à classe.
- Kit de Jogos na criação/edição: Baralho, Conjunto de Dados, Xadrez de Dragão e Jogo de Três Dragões. O kit fica registrado no JSON do personagem.
- Flag para mostrar/ocultar painéis de características e regras durante a criação.
- Rodapé global com versão, criador informado (Felipe Couto) e resumo do sistema.
- Schema do personagem atualizado para versão 10.

## Atualização
Não há alteração estrutural obrigatória no banco de dados. Faça backup dos arquivos e do banco antes de substituir a versão anterior. As migrações acumuladas da versão utilizada continuam necessárias.

## Observação
As distribuições sugeridas são recomendações de conveniência baseadas no atributo primário e não substituem escolhas previstas nas regras ou decisões do jogador. Conteúdo detalhado de regras pode variar conforme o catálogo instalado.
