<?php
require_once __DIR__.'/auth.php';
function top($title='D&D Manager'){
 $script=$_SERVER['SCRIPT_NAME']??'';
 $base=(str_contains($script,'/mesa/')||str_contains($script,'/personagem/')||str_contains($script,'/admin/')||str_contains($script,'/api/'))?'../':'';
 $u=usuario();
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=h($title)?></title><link rel="stylesheet" href="<?=$base?>public/style.css"></head><body>
<nav class="nav"><a class="brand" href="<?=$base?>dashboard.php">⚔ D&D Manager</a><div class="navlinks"><a href="<?=$base?>dashboard.php">Início</a><a href="<?=$base?>personagens.php">Personagens</a><a href="<?=$base?>mesas.php">Mesas</a><a href="<?=$base?>conta.php">Minha conta</a><?php if($u&&in_array($u['tipo'],['mestre','admin'])): ?><a href="<?=$base?>admin/usuarios.php">Admin</a><?php endif;?><?php if($u&&$u['tipo']==='admin'): ?><a href="<?=$base?>admin/mesas.php">Todas as mesas</a><?php endif;?></div><span class="spacer"></span><?php if($u):?><span class="userpill"><?=h($u['nome'])?> <b><?=h($u['tipo'])?></b></span><a class="logout" href="<?=$base?>logout.php">Sair</a><?php endif;?></nav><main class="wrap">
<?php
}
function bottom(){
?>
</main><footer class="app-footer"><strong>D&amp;D Manager V10</strong><span>Criador: Felipe Couto</span><span>Sistema de criação e gerenciamento de personagens, mesas, regras, inventário, magias e rolagens para campanhas de RPG.</span></footer></body></html>
<?php
}
function msg($m){if($m)echo '<div class="notice">'.h($m).'</div>';}
?>
