# D&D Manager V19

## Principais alterações
- Classes: Bárbaro, Bardo, Bruxo, Clérigo, Druida, Feiticeiro, Guardião, Guerreiro, Ladino, Mago, Monge, Paladino e Artífice.
- Espécies: Asimar, Anão, Draconato, Elfo, Gnomo, Golias, Humano, Orc, Pequenino, Tiferino, Kenku, Renascido e Warforged.
- Antecedentes: Acólito, Andarilho, Artesão, Artista, Charlatão, Criminoso, Eremita, Escriba, Fazendeiro, Guarda, Guia, Marinheiro, Mercador, Nobre, Sábio e Soldado.
- Idioma principal fixado pelo código de espécie e até dois adicionais.
- XP determina automaticamente o nível (1 a 20). A tabela de XP é comum às classes no sistema D&D.
- Minha conta permite alterar e-mail e senha; senha usa password_hash/password_verify, mantendo o algoritmo já empregado pelo projeto.
- Transferência, importação para atualizar personagem, PDF simples/completo e descanso.
- Popup de histórico no rodapé.

## Instalação
1. Faça backup dos arquivos e do banco.
2. Extraia o ZIP sobre a instalação existente, mantendo `config/conexao.php`.
3. Não há migração SQL obrigatória para os recursos desta versão.
4. O acesso ao servidor deve usar HTTPS.

## Observações importantes
- A página de referência é uma SPA cujo conteúdo detalhado não ficou disponível na leitura automatizada. O catálogo solicitado foi implementado; regras específicas não verificáveis não foram inventadas.
- D&D 2024 prevê descanso curto e longo. O botão “médio” é uma regra opcional do gerenciador (recupera 25% dos PV), explicitamente identificada na interface.
- O descanso longo restaura PV, remove condições e zera PV temporários. Recursos específicos de classe que não estão modelados na ficha precisam ser conferidos manualmente.
- Transferência é definitiva e altera o proprietário no banco.
- Testes estáticos não substituem homologação em PHP/MySQL real.
