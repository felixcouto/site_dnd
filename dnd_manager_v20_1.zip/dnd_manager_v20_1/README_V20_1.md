# D&D Manager V20.1.0

## Instalação/atualização
1. Faça backup do banco e dos arquivos da V20.
2. Copie o conteúdo da pasta `dnd_manager_v20_1` para o servidor, mantendo a estrutura.
3. Revise `config/conexao.php` para host, banco, usuário, senha e APP_URL do ambiente.
4. Execute `database/migracao_v20_para_v20_1.sql` no banco usado pela V20.
5. Acesse o sistema e teste login, Minha conta, edição de personagem, mesa ativa/inativa, chat e descansos.

## Alterações V20.1
- CSRF carregado globalmente pelo layout.
- Minha conta mostra identificação, nome, tipo de acesso e e-mail; permite atualizar e-mail e senha. A senha anterior é obrigatória e a nova usa `password_hash(..., PASSWORD_DEFAULT)`.
- Indicador de força e checklist de requisitos de senha.
- Mesas separadas em Ativas e Inativas. A tela inicial lista apenas mesas ativas.
- Chat permite consultar mensagens antigas em mesa inativa, mas bloqueia envio.
- Idioma principal da espécie é definido no servidor; até dois idiomas adicionais, sem duplicar o idioma principal.
- Descansos pequeno, médio e longo mantidos conforme implementação da V20. O descanso médio é regra opcional do gerenciador; recursos de classe não modelados não são restaurados automaticamente.

## Compatibilidade e limites conhecidos
O catálogo `dados/catalogo_v5.php` da V20 foi preservado. Não foi possível validar uma sincronização integral dos catálogos internos do site de referência (classes, perícias, resistências, itens, magias e talentos) a partir da aplicação web. Portanto, esta versão não afirma equivalência completa com a última versão do app de referência. O teste de integração deve ser feito no ambiente MySQL/MariaDB real antes de produção.
