# D&D Manager V20

## Atualizações desta versão
- Chat interno da mesa para comunicação entre mestre e jogadores.
- Leitura e envio do chat restritos aos participantes autorizados da mesa (ou administrador).
- Proteção CSRF no envio, limite de 2.000 caracteres e atualização automática do painel.
- Correção do INSERT de histórico de personagem: quatro colunas e quatro parâmetros.
- Indicador de força da senha mantido com os requisitos mínimos: 8 caracteres, maiúscula, minúscula, número e caractere especial.
- Migração SQL incluída em `database/migracao_v19_para_v20.sql`.
- Rodapé atualizado para V20.0.0 e popup de notas com V20 expandida por padrão.

## Atualização
1. Faça backup dos arquivos e do banco.
2. Envie a pasta `dnd_manager_v20` ao servidor.
3. Preserve `config/conexao.php` e demais configurações locais.
4. Execute `database/migracao_v19_para_v20.sql` no banco utilizado pela V19.
5. Confirme que a tabela `mesa_chat` foi criada e teste o chat com duas contas participantes da mesma mesa.

## Compatibilidade e limitações
- Catálogos de perícias, resistências, equipamentos, magias e talentos já existentes em `dados/catalogo_v5.php` foram preservados. Não foi possível validar automaticamente o conteúdo completo da SPA de referência; esta versão não declara uma atualização integral dos catálogos oficiais.
- O descanso segue a implementação existente da V19. O descanso médio continua sendo regra opcional do gerenciador; recursos de classe que não estejam modelados não são automaticamente restaurados.
- A troca de senha mantém `password_hash`/`password_verify` com `PASSWORD_DEFAULT`.
- Testes de integração dependem de ambiente PHP/MySQL; não foram executados contra o banco de produção.
