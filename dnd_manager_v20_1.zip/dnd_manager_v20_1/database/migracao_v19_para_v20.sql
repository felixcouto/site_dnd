-- D&D Manager V19 -> V20
-- Executar no banco já utilizado pela instalação anterior.
-- Não remove nem altera registros de usuários, mesas ou personagens.

CREATE TABLE IF NOT EXISTS `mesa_chat` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `mesa_id` INT NOT NULL,
  `usuario_id` INT NOT NULL,
  `mensagem` TEXT NOT NULL,
  `criado_em` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_mesa_chat_mesa_id` (`mesa_id`, `id`),
  KEY `idx_mesa_chat_usuario_id` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A aplicação valida a participação na mesa em cada leitura e envio.
-- Os índices são criados sem chaves estrangeiras para compatibilidade
-- com instalações legadas que utilizam tabelas MyISAM.
