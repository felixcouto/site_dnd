-- D&D Manager V20.1.0
-- Migração incremental a partir da V20. Compatível com tabelas legadas MyISAM.
-- A tabela de chat é InnoDB para permitir integridade transacional própria.
CREATE TABLE IF NOT EXISTS mesa_chat (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  mesa_id INT NOT NULL,
  usuario_id INT NOT NULL,
  mensagem VARCHAR(2000) NOT NULL,
  criado_em TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_mesa_chat_mesa_id (mesa_id, id),
  KEY idx_mesa_chat_usuario_id (usuario_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Não são criadas FKs porque as tabelas legadas mesas/usuarios podem usar MyISAM.
-- Execute este arquivo uma única vez ou novamente com segurança (CREATE IF NOT EXISTS).
