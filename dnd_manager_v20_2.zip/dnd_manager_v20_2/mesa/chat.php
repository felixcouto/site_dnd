<?php
// Endpoint JSON: nenhum template HTML ou aviso PHP pode contaminar a resposta.
ob_start();
ini_set('display_errors', '0');
require_once __DIR__.'/../config/layout.php';
function chat_response(array $data, int $code=200): void {
    while(ob_get_level()>0) ob_end_clean();
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    echo json_encode($data, JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
try {
 $u=usuario();
 if(!$u) chat_response(['ok'=>false,'error'=>'Sessão expirada. Entre novamente.'],401);
 $uid=(int)$u['id']; $mesaId=(int)($_POST['mesa_id']??$_GET['mesa_id']??0);
 $q=$pdo->prepare('SELECT id,mestre_id,ativa FROM mesas WHERE id=?');$q->execute([$mesaId]);$mesa=$q->fetch();
 if(!$mesa || ($u['tipo']!=='admin' && !temMesa($mesaId,$uid))) chat_response(['ok'=>false,'error'=>'Acesso negado à mesa.'],403);
 $gm=($u['tipo']==='admin'||(int)$mesa['mestre_id']===$uid);
 $q=$pdo->prepare('SELECT u.id,u.nome FROM usuarios u WHERE u.id=? OR EXISTS (SELECT 1 FROM mesa_membros mm WHERE mm.mesa_id=? AND mm.usuario_id=u.id) OR EXISTS (SELECT 1 FROM mesas m WHERE m.id=? AND m.mestre_id=u.id) ORDER BY u.nome');
 $q->execute([$uid,$mesaId,$mesaId]);$users=$q->fetchAll();
 $q=$pdo->prepare('SELECT p.id,p.nome,p.usuario_id FROM personagens p WHERE p.mesa_id=? ORDER BY p.nome');$q->execute([$mesaId]);$characters=$q->fetchAll();
 $q=$pdo->prepare('SELECT e.id,e.nome,e.categoria FROM entidades e JOIN entidade_mesas em ON em.entidade_id=e.id WHERE em.mesa_id=? ORDER BY e.nome');$q->execute([$mesaId]);$entities=$q->fetchAll();
 $userIds=array_map(fn($x)=>(int)$x['id'],$users);
 $owners=[];foreach($characters as $c)$owners[(int)$c['id']]=(int)$c['usuario_id'];
 $entityIds=array_map(fn($x)=>(int)$x['id'],$entities);
 $nameUser=[];foreach($users as $x)$nameUser[(int)$x['id']]=$x['nome'];
 $nameChar=[];foreach($characters as $x)$nameChar[(int)$x['id']]=$x['nome'];
 $nameEntity=[];foreach($entities as $x)$nameEntity[(int)$x['id']]=$x['nome'].' ('.$x['categoria'].')';
 $allowed=function($kind,$id,$sender=false)use($uid,$gm,$userIds,$owners,$entityIds){
   if($kind==='usuario')return in_array($id,$userIds,true)&&(!$sender||$id===$uid);
   if($kind==='personagem')return isset($owners[$id])&&($owners[$id]===$uid||(!$sender));
   if($kind==='entidade')return in_array($id,$entityIds,true)&&(!$sender||$gm);
   return false;
 };
 $canRead=function($m)use($uid,$gm,$owners){
   if($m['destinatario_tipo']==='geral')return true;
   if((int)$m['usuario_id']===$uid)return true;
   if($m['destinatario_tipo']==='usuario')return (int)$m['destinatario_id']===$uid;
   if($m['destinatario_tipo']==='personagem')return ($owners[(int)$m['destinatario_id']]??0)===$uid;
   if($m['destinatario_tipo']==='entidade')return $gm;
   return false;
 };
 if($_SERVER['REQUEST_METHOD']==='POST') {
  if(!(int)$mesa['ativa'])chat_response(['ok'=>false,'error'=>'Mesa inativa: mensagens bloqueadas.'],409);
  if(!csrf_check((string)($_POST['csrf']??'')))chat_response(['ok'=>false,'error'=>'Token de segurança inválido. Atualize a página.'],403);
  $message=trim((string)($_POST['mensagem']??''));
  if($message===''||mb_strlen($message)>2000)chat_response(['ok'=>false,'error'=>'A mensagem deve ter entre 1 e 2.000 caracteres.'],422);
  $sk=(string)($_POST['remetente_tipo']??'usuario');$sid=(int)($_POST['remetente_id']??$uid);
  $dk=(string)($_POST['destinatario_tipo']??'geral');$did=(int)($_POST['destinatario_id']??0);
  if(!$allowed($sk,$sid,true))chat_response(['ok'=>false,'error'=>'Você não controla este remetente.'],403);
  if(!in_array($dk,['geral','usuario','personagem','entidade'],true)||($dk!=='geral'&&!$allowed($dk,$did,false)))chat_response(['ok'=>false,'error'=>'Destinatário inválido.'],422);
  if($dk==='entidade' && !$gm && $sk==='entidade')chat_response(['ok'=>false,'error'=>'Apenas o mestre pode interpretar NPCs e monstros.'],403);
  $q=$pdo->prepare('INSERT INTO mesa_chat_v2(mesa_id,usuario_id,remetente_tipo,remetente_id,destinatario_tipo,destinatario_id,mensagem) VALUES(?,?,?,?,?,?,?)');
  $q->execute([$mesaId,$uid,$sk,$sid,$dk,$dk==='geral'?null:$did,$message]);
  chat_response(['ok'=>true,'id'=>(int)$pdo->lastInsertId()]);
 }
 $after=max(0,(int)($_GET['after']??0));
 $q=$pdo->prepare('SELECT id,usuario_id,remetente_tipo,remetente_id,destinatario_tipo,destinatario_id,mensagem,criado_em FROM mesa_chat_v2 WHERE mesa_id=? AND id>? ORDER BY id ASC LIMIT 200');
 $q->execute([$mesaId,$after]);$all=$q->fetchAll();$messages=[];$last=$after;
 foreach($all as $m){
  $last=max($last,(int)$m['id']);
  if(!$canRead($m))continue;
  $names=['usuario'=>$nameUser,'personagem'=>$nameChar,'entidade'=>$nameEntity];
  $m['nome']=$names[$m['remetente_tipo']][(int)$m['remetente_id']]??'Participante';
  $m['destino_nome']=$m['destinatario_tipo']==='geral'?'Geral':($names[$m['destinatario_tipo']][(int)$m['destinatario_id']]??'Participante');
  $messages[]=$m;
 }
 // Legado V20.1: mensagens gerais antigas aparecem uma vez no primeiro carregamento.
 $legacy=[];
 if($after===0){
  $q=$pdo->prepare('SELECT c.id,c.usuario_id,u.nome,c.mensagem,c.criado_em FROM mesa_chat c JOIN usuarios u ON u.id=c.usuario_id WHERE c.mesa_id=? ORDER BY c.id DESC LIMIT 100');$q->execute([$mesaId]);$legacy=array_reverse($q->fetchAll());
 }
 chat_response(['ok'=>true,'messages'=>$messages,'legacy'=>$legacy,'cursor'=>$last,'participants'=>['users'=>$users,'characters'=>$characters,'entities'=>$entities],'me'=>$uid,'gm'=>$gm,'active'=>(bool)$mesa['ativa']]);
} catch(Throwable $e){
 error_log('mesa/chat.php: '.$e->getMessage());
 chat_response(['ok'=>false,'error'=>'Erro no chat. Confira a migração SQL V20.2 e os logs do servidor.'],500);
}
