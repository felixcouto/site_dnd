<?php
require '../config/layout.php';exigeLogin();$u=usuario();
if(!in_array($u['tipo'],['mestre','admin'],true)){http_response_code(403);exit('Sem permissão.');}
if($_SERVER['REQUEST_METHOD']!=='POST'||!csrf_check($_POST['csrf']??'')){http_response_code(403);exit('Token inválido.');}
$id=(int)($_POST['id']??0);$cat=$_POST['categoria']??'';$nome=trim($_POST['nome']??'');
if(!in_array($cat,['NPC','Monstro'],true)||$nome===''||mb_strlen($nome)>190)exit('Categoria ou nome inválido.');
if($id){$q=$pdo->prepare('SELECT usuario_id FROM entidades WHERE id=?');$q->execute([$id]);$owner=$q->fetchColumn();if(!$owner||((int)$owner!==(int)$u['id']&&$u['tipo']!=='admin'))exit('Sem permissão.');}
$mesas=array_unique(array_filter(array_map('intval',$_POST['mesas']??[])));
foreach($mesas as $mid){$q=$pdo->prepare('SELECT 1 FROM mesas WHERE id=? AND (mestre_id=? OR ?="admin")');$q->execute([$mid,$u['id'],$u['tipo']]);if(!$q->fetchColumn())exit('Você não é mestre de uma das mesas selecionadas.');}
$d=[];foreach(['deslocamento','nivel_desafio','tipo','idiomas','habilidades','notas'] as $k)$d[$k]=trim((string)($_POST[$k]??''));$d['ca']=max(0,min(99,(int)($_POST['ca']??10)));$d['pv']=max(0,min(99999,(int)($_POST['pv']??10)));
if(trim((string)($_POST['dados_json']??''))!==''){$import=json_decode($_POST['dados_json'],true);if(!is_array($import)||json_last_error()!==JSON_ERROR_NONE)exit('JSON de estatísticas inválido.');foreach(['deslocamento','nivel_desafio','tipo','idiomas','habilidades','notas'] as $k)if(isset($import[$k])&&is_scalar($import[$k]))$d[$k]=mb_substr((string)$import[$k],0,5000);foreach(['ca','pv'] as $k)if(isset($import[$k])&&is_numeric($import[$k]))$d[$k]=max(0,min($k==='ca'?99:99999,(int)$import[$k]));}
$pdo->beginTransaction();try{
 if($id){$q=$pdo->prepare('UPDATE entidades SET categoria=?,nome=?,descricao=?,dados=? WHERE id=?');$q->execute([$cat,$nome,trim($_POST['descricao']??''),json_encode($d,JSON_UNESCAPED_UNICODE),$id]);}
 else{$q=$pdo->prepare('INSERT INTO entidades(usuario_id,categoria,nome,descricao,dados) VALUES(?,?,?,?,?)');$q->execute([$u['id'],$cat,$nome,trim($_POST['descricao']??''),json_encode($d,JSON_UNESCAPED_UNICODE)]);$id=(int)$pdo->lastInsertId();}
 $pdo->prepare('DELETE FROM entidade_mesas WHERE entidade_id=?')->execute([$id]);$q=$pdo->prepare('INSERT INTO entidade_mesas(entidade_id,mesa_id) VALUES(?,?)');foreach($mesas as $mid)$q->execute([$id,$mid]);$pdo->commit();
}catch(Throwable $e){$pdo->rollBack();error_log($e->getMessage());http_response_code(500);exit('Erro ao salvar. Verifique a migração V20.2.');}
header('Location: ../entidades.php');exit;