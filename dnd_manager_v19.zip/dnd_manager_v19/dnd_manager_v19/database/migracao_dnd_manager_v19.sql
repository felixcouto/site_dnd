-- ============================================================
-- D&D Manager V19
-- Migração incremental de banco existente para V19
-- MySQL 5.7+/8.0 (InnoDB) | utf8mb4
--
-- IMPORTANTE:
-- 1. Faça backup completo antes de executar.
-- 2. Se o banco tiver outro nome, altere o USE abaixo.
-- 3. Execute uma única vez ou novamente com segurança: as operações
--    de criação/alteração são condicionais e não apagam dados.
-- 4. Esta migração preserva personagens.dados (JSON/LONGTEXT).
-- ============================================================

CREATE DATABASE IF NOT EXISTS dnd_campaign
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dnd_campaign;

-- Tabelas auxiliares utilizadas pelo sistema (cria apenas se ausentes).
CREATE TABLE IF NOT EXISTS personagem_historico (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  personagem_id INT NOT NULL,
  usuario_id INT NULL,
  versao INT NOT NULL DEFAULT 5,
  snapshot LONGTEXT NOT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_hist_personagem
    FOREIGN KEY (personagem_id) REFERENCES personagens(id) ON DELETE CASCADE,
  CONSTRAINT fk_hist_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS recuperacao_senha (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  token_hash CHAR(64) NOT NULL UNIQUE,
  expira_em DATETIME NOT NULL,
  usado_em DATETIME NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_rec_senha_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Coluna de controle de alteração de senha.
SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE usuarios ADD COLUMN senha_alterada_em DATETIME NULL',
    'SELECT 1')
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'usuarios'
    AND column_name = 'senha_alterada_em'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Compatibilidade com histórico de rolagens Poker (V4/V9).
SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE rolagens ADD COLUMN tipo VARCHAR(20) NOT NULL DEFAULT ''numerico'' AFTER detalhes',
    'SELECT 1')
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens' AND column_name = 'tipo'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE rolagens ADD COLUMN resultado_visual LONGTEXT NULL AFTER tipo',
    'SELECT 1')
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens' AND column_name = 'resultado_visual'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE rolagens ADD COLUMN poker_rerrolado TINYINT(1) NOT NULL DEFAULT 0',
    'SELECT 1')
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens' AND column_name = 'poker_rerrolado'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'ALTER TABLE rolagens ADD COLUMN poker_token_hash CHAR(64) NULL',
    'SELECT 1')
  FROM information_schema.columns
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens' AND column_name = 'poker_token_hash'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Índices opcionais: somente são criados quando ainda não existem.
SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'CREATE INDEX idx_rolagens_mesa_tipo ON rolagens(mesa_id, tipo, criado_em)',
    'SELECT 1')
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens'
    AND index_name = 'idx_rolagens_mesa_tipo'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'CREATE INDEX idx_rolagens_poker_token ON rolagens(poker_token_hash)',
    'SELECT 1')
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'rolagens'
    AND index_name = 'idx_rolagens_poker_token'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'CREATE INDEX idx_personagem_historico_personagem ON personagem_historico(personagem_id, id)',
    'SELECT 1')
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'personagem_historico'
    AND index_name = 'idx_personagem_historico_personagem'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @ddl = (
  SELECT IF(COUNT(*) = 0,
    'CREATE INDEX idx_recuperacao_usuario ON recuperacao_senha(usuario_id, usado_em, expira_em)',
    'SELECT 1')
  FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'recuperacao_senha'
    AND index_name = 'idx_recuperacao_usuario'
);
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Verificação informativa ao final. Resultado esperado: todas as linhas = 1.
SELECT 'usuarios.senha_alterada_em' AS verificacao,
       COUNT(*) = 1 AS presente
FROM information_schema.columns
WHERE table_schema = DATABASE() AND table_name = 'usuarios'
  AND column_name = 'senha_alterada_em'
UNION ALL
SELECT 'personagem_historico', COUNT(*) = 1
FROM information_schema.tables
WHERE table_schema = DATABASE() AND table_name = 'personagem_historico'
UNION ALL
SELECT 'recuperacao_senha', COUNT(*) = 1
FROM information_schema.tables
WHERE table_schema = DATABASE() AND table_name = 'recuperacao_senha'
UNION ALL
SELECT 'rolagens.poker_token_hash', COUNT(*) = 1
FROM information_schema.columns
WHERE table_schema = DATABASE() AND table_name = 'rolagens'
  AND column_name = 'poker_token_hash';
